<template>
    <div>
        <!-- 查询头 -->
        <div style="display:flex;margin:1px;margin-right:20px;">
            <el-tooltip content="新项目" placement="top">
                <el-button type="primary" icon="el-icon-plus" @click="handleNew()"></el-button>
            </el-tooltip>
            <el-tooltip content="刷新数据" placement="top">
                <el-button type="primary" icon="el-icon-refresh" @click="listMain()"></el-button>
            </el-tooltip>
            <el-input
                placeholder="查询内容"
                v-model="inputsearch"
                style="width:400px;margin-left:20px;"
                class="input-with-select"
                v-on:keydown.enter="listMain()"
            >
                <template #append>
                    <el-button icon="el-icon-search" @click="listMain()">查询</el-button>
                </template>
            </el-input>

            <el-select
                v-model="select_accountgrp"
                placeholder="请选择帐套"
                style="width:200px;margin-left:20px;height:40px;"
            >
                <el-option
                    v-for="item in dicpraccountgrp "
                    :key="item.itemid"
                    :label="item.itemname"
                    :value="item.itemid"
                ></el-option>
            </el-select>
        </div>
        <!-- 人事表格子 -->
        <div style="display:flex;margin-top:22px;height:650px">
            <div style="border-right:0px solid rgb(239,239,239);margin-left:1px;">
                <el-tree
                    :data="dicpritemgrp"
                    show-checkbox
                    node-key="id"
                    ref="deptTree"
                    :props="dicprops"
                    :default-expand-all="true"
                    @check="check"
                    style="width: 250px;overflow-x: scroll;height:715px;"
                ></el-tree>
            </div>
            <div style="margin-left:20px;width:100%;min-width:800px;">
                <el-table
                    :data="tableData"
                    style="width: 95%"
                    v-loading="loading"
                    element-loading-text="拼命加载中"
                    element-loading-spinner="el-icon-loading"
                    element-loading-background="rgba(0, 0, 0, 0.8)"
                    stripe
                >
                    <el-table-column prop="id" fixed width="80" type="index">
                        <template #default="scope">
                            <span>{{ (page.cpg - 1) * page.limit + (scope.$index + 1) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column prop="prid" label="编号" width="100"></el-table-column>
                    <el-table-column prop="prname" label="名称" width="300"></el-table-column>
                    <el-table-column prop="prtype" label="类型" width="120"></el-table-column>
                    <el-table-column prop="initval" label="初值" width="100"></el-table-column>
                    <el-table-column prop="prgrp" label="帐套" width="100"></el-table-column>
                    <el-table-column prop="sort" label="计算序号" width="150"></el-table-column>
                    <el-table-column prop="is_show" label="激活" width="100">
                        <template #default="scope">
                            <el-tooltip content="点击可切换状态" placement="top">
                                <el-button
                                    type="success"
                                    size="mini"
                                    v-if="scope.row.is_show == 1"
                                    @click="activeShow(0, scope.$index, scope.row)"
                                >激活</el-button>
                                <el-button
                                    type="danger"
                                    size="mini"
                                    @click="activeShow(1, scope.$index, scope.row)"
                                    v-else
                                >未激活</el-button>
                            </el-tooltip>
                        </template>
                    </el-table-column>
                    <el-table-column prop="remark" label="备注" width="200"></el-table-column>
                    <el-table-column prop="id" fixed="right" label="操作" width="140">
                        <template #default="scope">
                            <span class="butgrp">
                                <el-button
                                    size="mini"
                                    icon="el-icon-edit"
                                    @click="handleEdit(scope.$index, scope.row)"
                                ></el-button>

                                <el-button
                                    size="mini"
                                    type="danger"
                                    icon="el-icon-delete"
                                    @click="handleDelete(scope.$index, scope.row)"
                                ></el-button>
                            </span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!-- 翻页控件 -->
        <div style="margin-top:25px; ">
            <el-pagination
                background
                layout="prev, pager, next"
                :page-size="page.limit"
                @current-change="changePage"
                :current-page="cp1"
                :total="counts"
            ></el-pagination>
        </div>
        <!-- 人事表单 -->
        <div class="dialogform">
            <el-dialog title="薪资项目" width="1000px" v-model="dialogFormVisible">
                <el-form :rules="pritemrules" :model="pritemform" ref="pritemform">
                    <el-row :gutter="24">
                        <el-col :span="12">
                            <div>
                                <el-form-item label="帐套">
                                    <el-select
                                        v-model="pritemform.prgrp"
                                        placeholder="请选择"
                                        style="width:100%"
                                    >
                                        <el-option
                                            v-for="item in dicpraccountgrp  "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="12">
                            <div>
                                <el-form-item label="类型" prop="prtype">
                                    <el-select
                                        v-model="pritemform.prtype"
                                        placeholder="请选择"
                                        style="width:100%"
                                    >
                                        <el-option
                                            v-for="item in dicpritemgrp  "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="24">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="编号" :label-width="formLabelWidth" prop="prid">
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="pritemform.prid"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="名称"
                                    :label-width="formLabelWidth"
                                    prop="prname"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="pritemform.prname"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="初始值"
                                    :label-width="formLabelWidth"
                                    prop="initval"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="pritemform.initval"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>

                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="计算序号"
                                    :label-width="formLabelWidth"
                                    prop="sort"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="pritemform.sort"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>>
                    <el-row :gutter="20"></el-row>
                    <el-form-item label="公式" :label-width="formLabelWidth">
                        <el-input
                            size="medium"
                            v-model="pritemform.prfur"
                            autocomplete="off"
                            type="textarea"
                            :autosize="{ minRows: 10, maxRows: 40 }"
                        ></el-input>
                    </el-form-item>
                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="pritemform.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
    </div>
</template>
<script>
import { AX, } from '../utils/api';
import { ref } from 'vue';
import moment from 'moment';



export default {

    data() {
        return {
            dplimit: [],
            fsysid: '123',
            hrData: {},

            tableData: [],
            roleData: [],
            familyData: [],

            select_accountgrp: '1',

            //=========================
            dicpritemgrp: [],
            dicpraccountgrp: [],
            dicprops: {
                label: 'itemname',
                children: 'children',
            },

            //==================

            loading: false,
            deptVisible: false,

            deptChecked: [],




            dpData: [],
            dpList: [],
            dpProps: {
                label: 'dpname',
                ispos: 'is_pos',
                children: 'children',
            },

            inputsearch: '',
            counts: 1,
            cp1: 1,
            formLabelWidth: "200",

            cmppwd: '',

            dialogFormVisible: false,

            neworedit: true,


            page: {
                limit: 10,
                cpg: 1,

            },
            form: {
                calperiod: '',
                fromdate: '',
                todate: '',
                s01: '',
                s02: '',

                h: {
                    sysid: ref(''),
                    dpname: '',
                    dept: '',
                    position: '',



                },
            },


            pritemform: {
                id: '',
                prid: '',
                prname: '',
                is_show: '',
                prgrp: '',
                prtype: '',
                initval: '',
                sort: '',
                prfur: '',
                remark: '',
            },
            rules: {
                prid: [{ required: true, message: '请输入 编号', trigger: 'blur' }],
                prname: [{ required: true, message: '请输入 名称', trigger: 'blur' }],
                initval: [{
                    required: true, message: '请输入 初始值', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],

            }
        }

    },

    mounted() {
        this.getdic();

    },
    methods: {

        activeShow(show = 1, idx, row) {


            this.pritemform = Object.assign({}, row);
            this.pritemform.is_show = show;
            console.log('row', row);

            AX('put', '/pritem/' + this.pritemform.id, this.pritemform).then((res) => {
                console.log(res)
                if (res) {

                    this.listMain()

                }



            })


        },



        check() {

            this.deptChecked.splice('0', this.deptChecked.length);
            this.deptChecked = this.$refs.deptTree.getCheckedNodes();
        },



        newdeptnodeclick(data) {
            console.log(data)
            if (data.is_pos == 1) {
                this.deptVisible = false;
                this.form.dpname = data.dpname;
                this.form.dept = data.fid;
                this.form.position = data.dpid;
            }


        },
        test() {
            console.log('deptvisible:', this.deptVisible);
            this.deptVisible = !this.deptVisible;
        },
        handleDelete(idx, row) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/hrinfo/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },




        saveForm() {



            //  this.$refs['form'].validate((valid) => {



            //      if (valid) {


            if (!this.neworedit) {

                AX('put', '/pritem/' + this.pritemform.id, this.pritemform).then((res) => {

                    if (res) {

                        this.dialogFormVisible = false;
                        this.listMain();
                    }
                })

            }
            else {
                AX('post', '/pritem', this.pritemform).then((res) => {

                    if (res) {

                        this.dialogFormVisible = false;
                        this.listMain();
                    }
                })

                // }

            }
            //  })
        },



        formatisstop(row) {
            return row.is_stop == 0 ? "No" : "STOP"

        },
        handleNew() {
            this.neworedit = true;
            this.dialogFormVisible = true;
            // this.getdic();
            Object.keys(this.form).forEach(key => {
                this.form[key] = '';
            });

        },
        handleEdit(index, row) {
            //  this.getdic();

            this.pritemform = Object.assign({}, row);
            this.neworedit = false;
            this.dialogFormVisible = true;



        },

        changePage(idx) {
            //  console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },

        getdic(type = 'hr') {
            this.loading = true;

            if (type == 'hr') {
                AX('get', '/dicm/pritemgrp').then(res => {
                    this.dicpritemgrp = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/pritemgcalgrp').then((res) => {
                    this.dicpraccountgrp = res.data;
                })
                    .catch(e => console.log(e.message))
                AX('get', '/dicm/hrsur').then((res) => {
                    this.dichrsurData = res.data;
                })
                    .catch(e => console.log(e.message))



            }



            this.loading = false;



        },


        cmd_moresearch() {

            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的部门！');
                return;

            } else {


                this.deptChecked.forEach(item => {
                    let dpobj = {};
                    dpobj.dpid = item.dpid;
                    this.dplimit.push(dpobj);
                });



                this.dialogMSVisible = true;
            }
        },

        moreSearch(data) {
            //console.log(data;
            this.loading = true;

            let block = encodeURI(JSON.stringify(data));

            // console.log('blockencodeURI', block.length)

            AX('get', '/hrinfo/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {



                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.tableData.forEach(item => {

                    item.birthshow = moment(item.birth).format('MM-DD')
                })

                this.loading = false;



            });

        },

        listMain() {
            //  console.log('33333333333333')



            //  let api = ''
            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的类型！');
                return;
            }

            //   console.log(this.deptChecked)
            this.loading = true;
            let block = {};

            let depts = [];

            this.deptChecked.forEach(item => {
                let dpobj = {};
                dpobj.dpid = item.dpid;
                depts.push(dpobj);
            });




            block.dept = depts;
            //console.log('block', JSON.stringify(block))
            block = encodeURI(JSON.stringify(block));

            // console.log('blockencodeURI', block.length)

            AX('get', '/pritem/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {



                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.loading = false;


            }
            )
        }
    }

}
</script>
<style scoped>
.ispos {
    padding: 2px 6px;
    cursor: pointer;
    font-size: 14px;
}
.el-divider i {
    color: #409eff;
}
.pdmsg {
    margin-left: 1px;
    background-color: none;
    color: rgb(192, 192, 192);
    font-weight: normal;
    font-size: 12px;
}
</style>


