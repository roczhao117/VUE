<template >
    <el-container direction="vertical">
        <div style="display:flex;margin:1px;margin-right:20px;">
            <el-button type="primary" icon="el-icon-refresh" @click="listMain()"></el-button>
            <el-input placeholder="查询内容" v-model="inputsearch" class="input-with-select">
                <template #append>
                    <el-button icon="el-icon-search"></el-button>
                </template>
            </el-input>
        </div>
        <div>
            <el-tree
                :data="data"
                show-checkbox
                node-key="id"
                :default-expanded-keys="openkey"
                :default-checked-keys="[5]"
                :props="defaultProps"
                @node-click="nodeClick"
                @node-expand="nodeClick(data, node, self)"
                @node-collapse="nodeCollapse"
            >
                <template #default="{ node, data }">
                    <span class="custom-tree-node">{{ node.label + '[#' + data.code + ']' }}</span>

                    <span>
                        <el-button
                            size="mini"
                            style="height:24px"
                            plain
                            icon="el-icon-edit"
                            @click="handleEdit(data)"
                        ></el-button>
                        <el-button size="mini" plain icon="el-icon-plus" @click="handleNew(data)"></el-button>
                        <el-button
                            type="danger"
                            size="mini"
                            plain
                            icon="el-icon-delete"
                            @click="handleDelete(node, data)"
                            v-if="data.dicmid != '00' && data.is_edit != '1'"
                        ></el-button>
                    </span>
                </template>
            </el-tree>
        </div>
        <div style="margin-top:17px; ">
            <el-pagination
                background
                layout="prev, pager, next"
                :page-size="page.limit"
                @current-change="changePage"
                :current-page="cp1"
                :total="counts"
            ></el-pagination>
        </div>
        <div class="dialogform">
            <el-dialog title="参数设置" width="40%" v-model="dialogFormVisible">
                <el-form
                    :rules="rules"
                    :model="form"
                    ref="form"
                    class="margin:0 20px;display:flex;"
                >
                    <el-form-item label="代码" :label-width="formLabelWidth" prop="code">
                        <el-input
                            size="medium"
                            v-model="form.code"
                            autocomplete="off"
                            :disabled="!neworedit"
                        ></el-input>
                    </el-form-item>

                    <el-form-item label="名称" :label-width="formLabelWidth" prop="itemname">
                        <el-input size="medium" v-model="form.itemname" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item label="描述" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.itemename" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item
                        label="所属类型"
                        :label-width="formLabelWidth"
                        style="display:table"
                        prop="dicmid"
                    >
                        <el-select
                            size="medium"
                            v-model="form.dicmid"
                            placehhlder="请选择"
                            :disabled="true"
                        >
                            <el-option
                                v-for="item in roleData"
                                :label="item.itemname"
                                :value="item.itemid"
                                :key="item.itemid"
                            ></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="显示" :label-width="formLabelWidth" style="display:table;">
                        <el-radio-group v-model="form.is_show">
                            <el-radio :label="1">显示</el-radio>
                            <el-radio :label="0">不显示</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="编辑" :label-width="formLabelWidth" style="display:table;">
                        <el-radio-group v-model="form.is_edit">
                            <el-radio :label="0">编辑</el-radio>
                            <el-radio :label="1">只读</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="排序" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.itemorder" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
    </el-container>
</template>
<script>
import { AX } from '../utils/api';
import { ref } from 'vue'
export default {

    data() {
        return {
            tableData: [],
            roleData: [],

            data: [],
            defaultProps: {
                children: 'children',
                label: 'itemname',
                is_node: this.dicmid == '00' ? true : false,
            },
            openkey: [],

            inputsearch: '',
            counts: 1,
            cp1: 1,

            cmppwd: '',

            dialogFormVisible: false,

            neworedit: true,


            page: {
                limit: 10,
                cpg: 1,

            },
            form: {
                id: '',
                is_stop: '0',
                is_edit: '1',
                is_show: '1',
                itemid: ref(''),
                itemname: '',
                itemename: '',
                dicmid: '',
                remark: '',
                code: ref(''),
                itemorder: '00001',

            },
            rules: {
                code: [{ required: true, message: '数字,字母或下划线', trigger: 'blur', pattern: /^[\w_-]{1,32}$/, }],

                itemname: [{ required: true, message: '请填写名称', trigger: 'blur', min: 1, max: 36 }],
            },
        }
    },
    methods: {
        nodeClick(node) {
            this.openkey.push(node.id)
        },
        nodeCollapse(node) {
            this.openkey.remove(node.id)
        },
        handleDelete(idx, row) {

            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {

                AX('DELETE', '/dic/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();

                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },
        saveForm() {

            // console.log(this.form);

            this.$refs.form.validate((valid) => {

                if (valid) {

                    if (!this.neworedit) {

                        AX('put', '/dic/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }
                    else {
                        AX('post', '/dic', this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }

                }
            })
        },
        formatisstop(row) {
            return row.is_stop == 0 ? "No" : "STOP"

        },
        handleNew(data) {
            this.neworedit = true;
            this.dialogFormVisible = true;
            //  this.getdic();
            Object.keys(this.form).forEach(key => {
                this.form[key] = '';
            });
            this.form.is_show = 1;
            this.form.is_stop = 0;
            this.form.is_edit = 1;
            this.form.itemorder = '0001';
            this.form.dicmid = data.itemid;

        },
        handleEdit(data) {

            if (data.dicmid == '00') {
                return;
            }
            this.neworedit = false;
            this.dialogFormVisible = true;
            this.form = Object.assign({}, data);
            this.openkey.push(data.id)


            // Object.keys(this.roleData).forEach(key => {

            //     console.log(key, this.roleData[key].itemid, row.usrgrpid)

            //     if (this.roleData[key].itemid == row.usrgrpid) {
            //         this.form.usrgrptxt = this.roleData[key].itemname;

            //         return;
            //     }


            // })
            // //   roleData.itemid=row.usergrpid

            //this.form.usrgrptxt =

            //   console.log(this.form, row)

        },

        changePage(idx) {
            console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },

        getdic() {
            AX('get', '/dicm/00').then(res => {
                this.roleData = res.data;
            })
                .catch(e => console.log(e.message))
        },

        listMain() {
            //  console.log('33333333333333')
            this.getdic();

            AX('get', '/dic').then(res => {

                this.data = res.data;
            },


            )
        }
    }

}
</script>
<style scoped>
.custom-tree-node {
    flex: 1;
    display: flex;
    align-items: center;
    justify-content: space-between;
    font-size: 16px;
    padding-right: 8px;
    margin: 15px;
}
.el-tree .el-button {
    margin-right: 5px;
    min-height: 25px;
    padding: 3px;
}
.input-with-select {
    width: 360px;
    margin-left: 10px;
}
.dialogform {
    display: flex;
    margin: 0 0;
}
.el-form-item {
    margin-bottom: 4px;
}
.el-form-item__content {
    display: flex;
}
</style>
