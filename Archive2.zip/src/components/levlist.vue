<template>
    <!-- 工作表单 -->
    <div class="dialogform">
        <el-form :rules="rules" :model="form" ref="form" style="width: 100%">
            <el-row :gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="请假类型" :label-width="formLabelWidth" prop="type">
                            <el-select
                                v-model="form.type"
                                icon="el-icon-edit"
                                placeholder="请选择"
                                size="medium"
                                style="width:100%"
                            >
                                <el-option
                                    v-for="item in typeData"
                                    :key="item.itemid"
                                    :label="item.itemname"
                                    :value="item.itemid"
                                ></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-col>

                <el-col :span="6">
                    <div>
                        <el-form-item label="偿付方式" :label-width="formLabelWidth" prop="pay">
                            <el-select v-model="form.pay" placeholder="请选择" style="width:100%">
                                <el-option
                                    v-for="item in payData"
                                    :key="item.itemid"
                                    :label="item.itemname"
                                    :value="item.itemid"
                                ></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="开始日期" :label-width="formLabelWidth" prop="fromdate">
                            <el-date-picker
                                v-model="form.fromdate"
                                type="date"
                                placeholder="选择日期"
                                format="YYYY-MM-DD"
                            ></el-date-picker>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="开始时间" :label-width="formLabelWidth" prop="fromtime">
                            <el-time-picker
                                v-model="form.fromtime"
                                placeholder="选择时间"
                                format="HH:mm"
                                value-format="HH:mm"
                                :editable="false"
                            ></el-time-picker>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="小时数" :label-width="formLabelWidth" prop="hours">
                            <el-input
                                size="medium"
                                v-model="form.hours"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="12">
                    <div>
                        <el-form-item
                            label="取消当日班次津贴 （取消当日排班中的特殊班次的津贴）"
                            :label-width="formLabelWidth"
                            prop="delshiftbenefit"
                        >
                            <el-switch
                                v-model="form.delshiftbenefit"
                                inactive-color="#13ce66"
                                active-color="#f56c6c"
                                active-text="取消"
                                inactive-text="否"
                                active-value="1"
                                inactive-value="0"
                            ></el-switch>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="单据状态" :label-width="formLabelWidth" prop="status">
                            <el-select
                                v-model="form.status"
                                placeholder="请选择"
                                size="medium"
                                style="width:100%"
                            >
                                <el-option
                                    v-for="item in funData"
                                    :key="item.itemid"
                                    :label="item.itemname"
                                    :value="item.itemid"
                                ></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>

            <el-divider content-position="left">
                <i class="el-icon-edit-outline">取消当日餐次 （取消当日排班里默认提供的工作餐次）</i>
            </el-divider>
            <el-row :gutter="24">
                <el-col :span="24">
                    <div style="display:block;width:960px;">
                        <el-checkbox-group
                            v-model="form.delmealsObj"
                            style="display:flex; flex-wrap:wrap;"
                        >
                            <el-checkbox
                                v-for="item in mealsData"
                                :key="item.itemid"
                                :value="item.itemname"
                                :label="item.itemid"
                                style="width:100px;text-align:left;"
                            >{{ item.itemname }}</el-checkbox>
                        </el-checkbox-group>
                    </div>
                </el-col>
            </el-row>
            <el-divider content-position="left"></el-divider>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">历史信息</i>
                    </el-divider>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-table
                        :data="formData"
                        style="width:95%"
                        v-loading="loading"
                        element-loading-text="拼命加载中"
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        stripe
                    >
                        <el-table-column prop="type" fixed="left" width="40" type="index">
                            <template
                                #default="scope"
                            >{{ (page.cpg - 1) * page.limit + (scope.$index + 1) }}</template>
                        </el-table-column>

                        <el-table-column prop="type" label="请假类型" fixed="left" width="80">
                            <template #default="scope">
                                <el-tag>{{ typeData.dicDescs(scope.row.type) }}</el-tag>
                            </template>
                        </el-table-column>

                        <el-table-column prop="type" label="偿付方式" fixed="left" width="80">
                            <template #default="scope">
                                <el-tag>{{ payData.dicDescs(scope.row.pay) }}</el-tag>
                            </template>
                        </el-table-column>

                        <el-table-column prop="fromdate" label="开始日期" width="100"></el-table-column>
                        <el-table-column prop="fromtime" label="开始时间" width="100">
                            <template
                                #default="scope"
                            >{{ (scope.row.fromtime).toString().substr(11, 5) }}</template>
                        </el-table-column>

                        <el-table-column prop="hours" label="小时数" width="80"></el-table-column>
                        <el-table-column prop="fun" label="状态" fixed="left" width="80">
                            <template #default="scope">
                                <el-tag>{{ funData.dicDescs(scope.row.status) }}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="fun" label="取消排班津贴" fixed="left" width="120">
                            <template #default="scope">
                                <el-tag v-if="scope.row.delshiftbenefit == 1">取消</el-tag>
                                <el-tag v-else>否</el-tag>
                            </template>
                        </el-table-column>

                        <el-table-column prop="remark" label="备注" width="180"></el-table-column>
                        <el-table-column prop="id" fixed="right" label="操作" width="120">
                            <template #default="scope">
                                <span class="butgrp">
                                    <el-button
                                        size="mini"
                                        icon="el-icon-edit"
                                        @click="editform(scope.$index, scope.row)"
                                    ></el-button>

                                    <el-button
                                        size="mini"
                                        type="danger"
                                        icon="el-icon-delete"
                                        @click="delform(scope.$index, scope.row)"
                                    ></el-button>
                                </span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col
                    :span="24"
                    style="display:flex; justify-content: space-between;padding-top:15px;"
                >
                    <span>
                        <div>
                            <el-pagination
                                background
                                layout="prev, pager, next"
                                :page-size="page.limit"
                                @current-change="changePage"
                                :current-page="cp1"
                                :total="counts"
                            ></el-pagination>
                        </div>
                    </span>
                    <span>
                        <el-button
                            type="success"
                            icon="el-icon-plus"
                            @click="init_form"
                            v-if="is_new == false"
                        ></el-button>

                        <el-button type="success" @click="saveform" v-if="is_new == true">新 增</el-button>
                        <el-button @click="closeform">取 消</el-button>
                        <el-button type="primary" @click="saveform" v-if="is_new == false">保 存</el-button>
                    </span>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>
<script>
import { AX, } from '../utils/api';
import { ref } from 'vue';
// import { moment } from 'moment'


export default {

    props: {
        fsysid: {
            type: String,
            required: true
        },
        diccerttypeData: {
            type: Array,
            required: true
        },

    },

    data() {
        return {

            selfRouter: 'levlist',

            typeData: [],
            payData: [],
            funData: [],
            shifttype2Data: [],
            mealsData: [],






            formData: [],

            loading: false,

            is_new: true,

            dialogFormVisible: false,

            formLabelWidth: "200",


            page: {
                limit: 10,
                cpg: 1,
            },
            counts: 1,
            cp1: 1,

            form: {
                sysid: ref(''),
                type: '',
                status: '',
                item: '',
                pay: '',
                hours: '8',
                delshiftbenefit: '1',
                fromdate: '',
                fromtime: '2999-09-09 08:31',
                shifttype: '',
                remark: '',
                delmeals: '',
                delmealsObj: [],

            },
            rules: {

                type: [{ required: true, message: '请选择 类型', trigger: 'blur' }],

                status: [{ required: true, message: '请选择 单据状态', trigger: 'blur' }],



                pay: [{ required: true, message: '请选择 方式', trigger: 'blur' }],

                hours: [{ required: true, message: '请输入 金额，没有写0', trigger: 'blur', pattern: /^(0|0(.)?\d+|[1-9]\d*(.)?\d*)$/ }],

                fromdate: [{ required: true, message: '请选择 开始日期', trigger: 'blur' }],

                fromtime: [{ required: true, message: '请选择 开始时间', trigger: 'blur' }],

            },


        }
    },
    mounted() {
        this.getdic();
        this.listMain();
    },
    watch: {
        fsysid() {
            this.listMain()

        }
    },
    methods: {

        init_form() {


            this.is_new = true;

            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.form) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {

                    this.form[item] = '';
                }
            }
            this.form.hours = '8';
            this.form.delshiftbenefit = '1';
            this.form.delmealsObj = [];

        },

        closeform() {

            this.$emit('close' + this.selfRouter + 'Form', false);

        },


        delform(idx, row) {


            this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/' + this.selfRouter + '/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editform(idx, row) {
            //  console.log(idx, row);
            this.is_new = false;
            this.form = Object.assign({}, row);
            this.form.delshiftbenefit = this.form.delshiftbenefit.toString();
            if (row.delmeals) {
                this.form.delmealsObj = row.delmeals.split(',');
            } else {
                this.form.delmealsObj = []
            }
        },


        saveform() {

            this.$refs.form.validate((valid) => {

                if (valid) {
                    this.form.delmeals = this.form.delmealsObj.flat().toString();
                    if (!this.is_new) {

                        AX('put', '/' + this.selfRouter + '/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                                this.init_form();
                            }
                        })

                    }
                    else {

                        if (this.fsysid) {
                            this.form.sysid = this.fsysid;
                            AX('post', '/' + this.selfRouter, this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                    this.init_form();
                                }
                            })

                        }
                    }

                }
            })
        },


        getdic() {
            AX('get', '/dicm/levitem').then((res) => {
                this.typeData = res.data;
            }), AX('get', '/dicm/otlevfun').then((res) => {
                this.funData = res.data;
            }), AX('get', '/dicm/levpay').then((res) => {
                this.payData = res.data;
            }), AX('get', '/dicm/shifttype2').then((res) => {
                this.shifttype2Data = res.data;
            }), AX('get', '/dicm/staffcateentype').then((res) => {
                this.mealsData = res.data;
            })
        },


        changePage(idx) {
            //  console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },


        listMain() {

            AX('get', '/' + this.selfRouter + '/' + this.page.limit + '/' + this.page.cpg + '/' + this.fsysid).then(res => {



                this.formData = res.data.rows;

                this.counts = res.data.count;

                this.loading = false;



            }
            )
        }
    }

}
</script>
<style scoped>
.ispos {
    color: white;
    background-color: #409eff;
    padding: 2px 6px;
    cursor: pointer;
    font-size: 12px;
    border-radius: 5px;
}
.el-divider i {
    color: #409eff;
}
.el-select {
    text-align: left;
}
</style>


