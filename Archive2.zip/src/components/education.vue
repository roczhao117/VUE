<template>
    <!-- 工作表单 -->
    <div class="dialogform">
        <el-form :rules="rules" :model="form" ref="form">
            <el-row :gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="学校" :label-width="formLabelWidth" prop="school">
                            <el-input
                                size="medium"
                                v-model="form.school"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item
                            label="阶段（小学，初中。。。）"
                            :label-width="formLabelWidth"
                            prop="level"
                        >
                            <el-input
                                size="medium"
                                v-model="form.level"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>

                <el-col :span="6">
                    <div>
                        <el-form-item label="开始日期" :label-width="formLabelWidth" prop="fromdate">
                            <el-date-picker
                                v-model="form.fromdate"
                                type="date"
                                placeholder="选择日期"
                                format="YYYY-MM-DD"
                            ></el-date-picker>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="结束日期" :label-width="formLabelWidth" prop="todate">
                            <el-date-picker
                                v-model="form.todate"
                                type="date"
                                placeholder="选择日期"
                                format="YYYY-MM-DD"
                            ></el-date-picker>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>

            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">工作经历</i>
                    </el-divider>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-table
                        :data="formData"
                        style="width:100%"
                        v-loading="loading"
                        element-loading-text="拼命加载中"
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        stripe
                    >
                        <el-table-column prop="school" label="学校" fixed="left" width="180"></el-table-column>
                        <el-table-column prop="level" label="阶段" width="100"></el-table-column>
                        <el-table-column prop="todate" label="结束日期" width="100"></el-table-column>
                        <el-table-column prop="remark" label="备注" width="180"></el-table-column>
                        <el-table-column prop="id" fixed="right" label="操作" width="120">
                            <template #default="scope">
                                <span class="butgrp">
                                    <el-button
                                        size="mini"
                                        icon="el-icon-edit"
                                        @click="editform(scope.$index, scope.row)"
                                    ></el-button>

                                    <el-button
                                        size="mini"
                                        type="danger"
                                        icon="el-icon-delete"
                                        @click="delform(scope.$index, scope.row)"
                                    ></el-button>
                                </span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col
                    :span="24"
                    style="display:flex; justify-content: flex-end;padding-top:15px;"
                >
                    <el-button
                        type="success"
                        icon="el-icon-plus"
                        @click="init_form"
                        v-if="is_new == false"
                    ></el-button>

                    <el-button type="success" @click="saveform" v-if="is_new == true">新 增</el-button>
                    <el-button @click="closeform">取 消</el-button>
                    <el-button type="primary" @click="saveform" v-if="is_new == false">保 存</el-button>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>
<script>
import { AX, } from '../utils/api';
import { ref } from 'vue';


export default {

    props: {
        fsysid: {
            type: String,
            required: true,
            default: '-1',
        }
    },

    data() {
        return {

            selfRouter: 'education',


            formData: [],

            loading: false,

            is_new: true,

            dialogFormVisible: false,

            formLabelWidth: '200',

            form: {
                sysid: ref(''),
                school: '',
                level: '',
                fromdate: '',
                todate: '',
                remark: '',
            },
            rules: {

                school: [{ required: true, message: '请输入 工作单位', trigger: 'blur' }],

                level: [{ required: true, message: '请输入 担任职位', trigger: 'blur' }],

                fromdate: [{ required: true, message: '请选择 开始日期', trigger: 'blur' }],

                todate: [{ required: true, message: '请选择 结束日期', trigger: 'blur' }],

            },


        }
    },
    mounted() {
        this.listMain();
    },

    watch: {
        fsysid() {
            this.listMain()

        }
    },
    methods: {

        init_form() {

            this.is_new = true;

            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.form) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {

                    this.form[item] = '';
                }
            }

        },

        closeform() {

            this.$emit('close' + this.selfRouter + 'Form', false);

        },


        delform(idx, row) {


            this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/' + this.selfRouter + '/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editform(idx, row) {
            //  console.log(idx, row);
            this.is_new = false;
            this.form = Object.assign({}, row);
        },


        saveform() {

            this.$refs.form.validate((valid) => {

                if (valid) {


                    if (!this.is_new) {

                        AX('put', '/' + this.selfRouter + '/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                                this.init_form();
                            }
                        })

                    }
                    else {

                        if (this.fsysid) {
                            this.form.sysid = this.fsysid;
                            AX('post', '/' + this.selfRouter, this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                    this.init_form();
                                }
                            })

                        }
                    }

                }
            })
        },

        listMain() {

            console.log("======================================", 'fsysid', this.fsysid)

            AX('get', '/' + this.selfRouter + '/' + this.fsysid).then(res => {


                if (res.data.length > 0) {

                    this.formData = res.data;

                    this.loading = false;
                } else { this.formData = []; }


            }
            )
        }
    }

}
</script>
<style scoped>
.label-width {
    width: 200px;
}
.el-select,
.el-date-picker {
    width: 100%;
}

.ispos {
    color: white;
    background-color: #409eff;
    padding: 2px 6px;
    cursor: pointer;
    font-size: 12px;
    border-radius: 5px;
}
.el-divider i {
    color: #409eff;
}
</style>


