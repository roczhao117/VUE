<template >
    <el-container direction="vertical">
        <div style="display:flex;margin:1px;margin-right:20px;">
            <el-button type="primary" icon="el-icon-plus" @click="handleNew()"></el-button>
            <el-button type="primary" icon="el-icon-refresh" @click="listMain()"></el-button>
            <el-input placeholder="查询内容" v-model="inputsearch" class="input-with-select">
                <template #append>
                    <el-button icon="el-icon-search"></el-button>
                </template>
            </el-input>
        </div>
        <div>
            <el-table :data="tableData" stripe>
                <el-table-column prop="id" fixed width="60" type="selection"></el-table-column>
                <el-table-column prop="usrid" fixed label="登陆名" width="120"></el-table-column>
                <el-table-column prop="usrname" fixed label="用户全名" width="150"></el-table-column>
                <el-table-column prop="usrgrpid" fixed label="角色" width="120"></el-table-column>

                <el-table-column
                    prop="is_stop"
                    :formatter="formatisstop"
                    fixed
                    width="80"
                    show-overflow-tooltip
                    label="停用?"
                >
                    <template #default="scope">
                        <el-tag v-if="scope.row.is_stop == 1" type="danger">已停</el-tag>

                        <el-tag v-else type="success">已启用</el-tag>
                    </template>
                </el-table-column>

                <el-table-column
                    prop="is_stop"
                    :formatter="formatisstop"
                    fixed
                    width="80"
                    show-overflow-tooltip
                    label="锁定"
                >
                    <template #default="scope">
                        <el-tag v-if="scope.row.is_locked == 1" type="danger">锁</el-tag>

                        <el-tag v-else type="success">未</el-tag>
                    </template>
                </el-table-column>

                <el-table-column prop="id" label="操作">
                    <template #default="scope">
                        <el-button
                            size="mini"
                            icon="el-icon-edit"
                            @click="handleEdit(scope.$index, scope.row)"
                        ></el-button>
                        <el-button
                            size="mini"
                            type="danger"
                            icon="el-icon-delete"
                            @click="handleDelete(scope.$index, scope.row)"
                        ></el-button>
                    </template>
                </el-table-column>
            </el-table>
        </div>
        <div style="margin-top:17px; ">
            <el-pagination
                background
                layout="prev, pager, next"
                :page-size="page.limit"
                @current-change="changePage"
                :current-page="cp1"
                :total="counts"
            ></el-pagination>
        </div>
        <div class="dialogform">
            <el-dialog title="用户账号" width="40%" v-model="dialogFormVisible">
                <el-form
                    :rules="rules"
                    :model="form"
                    ref="form"
                    class="margin:0 20px;display:flex;"
                >
                    <el-form-item
                        label="登陆账号(6-32位数字字母)"
                        :label-width="formLabelWidth"
                        prop="usrid"
                    >
                        <el-input
                            size="medium"
                            :disabled="!neworedit"
                            v-model="form.usrid"
                            autocomplete="off"
                        ></el-input>
                    </el-form-item>

                    <el-form-item label="全名" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.usrname" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item
                        label="角色"
                        :label-width="formLabelWidth"
                        style="display:table"
                        prop="usrgrpid"
                    >
                        <el-select size="medium" v-model="form.usrgrpid" placehhlder="请选择活动区域">
                            <el-option
                                v-for="item in roleData"
                                :label="item.itemname"
                                :value="item.itemid"
                                :key="item.itemid"
                            ></el-option>
                        </el-select>
                    </el-form-item>

                    <el-form-item label="密码(6-32位数字字母)" :label-width="formLabelWidth" prop="pwd">
                        <el-input size="medium" v-model="form.pwd" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item label="重复密码" :label-width="formLabelWidth" prop="cmppwd">
                        <el-input size="medium" v-model="form.cmppwd" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item
                        label="下次登陆改密码"
                        :label-width="formLabelWidth"
                        style="display:table;"
                    >
                        <el-radio-group v-model="form.is_nextmp">
                            <el-radio :label="1">需要</el-radio>
                            <el-radio :label="0">不需要</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="账号状态" :label-width="formLabelWidth" style="display:table;">
                        <el-radio-group v-model="form.is_stop">
                            <el-radio :label="0">启用</el-radio>
                            <el-radio :label="1">停用</el-radio>
                        </el-radio-group>
                    </el-form-item>
                    <el-form-item label="锁定" :label-width="formLabelWidth" style="display:table;">
                        <el-radio-group v-model="form.is_locked">
                            <el-radio :label="0">未锁</el-radio>
                            <el-radio :label="1">已锁</el-radio>
                        </el-radio-group>
                    </el-form-item>

                    <el-form-item label="电话" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.tele" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item label="邮件" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.email" autocomplete="off"></el-input>
                    </el-form-item>

                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
    </el-container>
</template>
<script>
import { AX } from '../utils/api';
import { ref } from 'vue'
export default {

    data() {
        return {
            tableData: [],
            roleData: [],

            inputsearch: '',
            counts: 1,
            cp1: 1,

            cmppwd: '',

            dialogFormVisible: false,

            neworedit: true,

            page: {
                limit: 10,
                cpg: 1,

            },
            form: {
                is_stop: '0',
                is_nextmp: '0',
                is_locked: '0',
                usrid: ref(''),
                usrname: '',
                pwd: '',
                usrgrpid: '',
                tele: '',
                email: '',
                remark: '',
                cmppwd: '',
            },
            rules: {
                usrid: [{ required: true, message: 'please input id', trigger: 'blur', min: 6, max: 32 }],

                pwd: [{ required: true, message: 'please input password', trigger: 'blur', min: 6, max: 32 }],

                cmppwd: [{ required: true, message: 'please input confirm password', trigger: 'blur', min: 6, max: 32 }],

                usrgrpid: [{ required: true, message: 'please input roler', trigger: 'blur' }],
            },
        }
    },
    methods: {

        handleDelete(idx, row) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/user/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },
        saveForm() {

            // console.log(this.form);

            this.$refs.form.validate((valid) => {

                if (valid) {
                    if (this.form.pwd == this.form.cmppwd) {
                        if (!this.neworedit) {

                            AX('put', '/user/' + this.form.id, this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                }
                            })

                        }
                        else {
                            AX('post', '/user', this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                }
                            })

                        }
                    } else {
                        this.$message.error('please verify password.');
                        return false;
                    }
                }
            })
        },
        formatisstop(row) {
            return row.is_stop == 0 ? "No" : "STOP"

        },
        handleNew() {
            this.neworedit = true;
            this.dialogFormVisible = true;
            this.getdic();
            Object.keys(this.form).forEach(key => {
                console.log();
                this.form[key] = '';
            });
            this.form.is_nextmp = 0;
            this.form.is_stop = 0;
            this.form.is_locked = 0;

        },
        handleEdit(index, row) {
            //  this.getdic();
            //            console.log(index, row);
            this.neworedit = false;
            this.dialogFormVisible = true;
            this.form = Object.assign({}, row);

            this.form.usergrptxt = '';

            // Object.keys(this.roleData).forEach(key => {

            //     console.log(key, this.roleData[key].itemid, row.usrgrpid)

            //     if (this.roleData[key].itemid == row.usrgrpid) {
            //         this.form.usrgrptxt = this.roleData[key].itemname;

            //         return;
            //     }


            // })
            // //   roleData.itemid=row.usergrpid

            //this.form.usrgrptxt =

            //   console.log(this.form, row)

        },

        changePage(idx) {
            console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },

        getdic() {
            AX('get', '/dicm/roles').then(res => {
                this.roleData = res.data;
            })
                .catch(e => console.log(e.message))
        },

        listMain() {
            //  console.log('33333333333333')
            this.getdic();

            AX('get', '/user/' + this.page.limit + '/' + this.page.cpg).then(res => {
                this.tableData = res.data.rows;
                this.counts = res.data.count;
            }
            )
        }
    }

}
</script>
<style scoped>
.input-with-select {
    width: 360px;
    margin-left: 10px;
}
.dialogform {
    display: flex;
    margin: 0 0;
}
.el-form-item {
    margin-bottom: 4px;
}
.el-form-item__content {
    display: flex;
}
</style>
