<template>
    <el-container direction="vertical">
        <!-- 查询头 -->
        <div style="display:flex;margin:1px;margin-right:20px;">
            <el-tooltip content="新加员工" placement="top">
                <el-button type="primary" icon="el-icon-plus" @click="handleNew()"></el-button>
            </el-tooltip>
            <el-tooltip content="刷新数据" placement="top">
                <el-button type="primary" icon="el-icon-refresh" @click="listMain()"></el-button>
            </el-tooltip>
            <el-input
                placeholder="查询内容"
                v-model="inputsearch"
                class="input-with-select"
                v-on:keydown.enter="listMain()"
            >
                <template #append>
                    <el-button icon="el-icon-search" @click="listMain()">查询</el-button>
                </template>
            </el-input>
            <el-tooltip content="高级查询" placement="top">
                <el-button
                    type="primary"
                    icon="el-icon-view"
                    @click="cmd_moresearch"
                    style="margin-left:20px"
                ></el-button>
            </el-tooltip>
        </div>
        <!-- 人事表格子 -->
        <div style="display:flex;margin-top:10px;height:650px">
            <div style="border-right:0px solid rgb(239,239,239);margin-left:1px;">
                <el-tree
                    :data="dpData"
                    show-checkbox
                    node-key="id"
                    ref="deptTree"
                    :props="dpProps"
                    :default-expand-all="true"
                    @check="check"
                    style="width: 250px;overflow-x: scroll;height:715px;"
                >
                    <template #default="{ node, data }">
                        <span :class="{ ispos: data.is_pos == 1 }">
                            {{ node.label }}
                            <span class="pdmsg" v-if="data.is_pos == 1">职位</span>

                            <span class="pdmsg" v-else>部门</span>
                        </span>
                    </template>
                </el-tree>
            </div>
            <div style="margin-left:20px;width:100%;min-width:800px;">
                <el-table
                    :data="tableData"
                    style="width: 95%"
                    v-loading="loading"
                    element-loading-text="拼命加载中"
                    element-loading-spinner="el-icon-loading"
                    element-loading-background="rgba(0, 0, 0, 0.8)"
                    stripe
                >
                    <el-table-column prop="id" fixed width="80" type="index">
                        <template #default="scope">
                            <span>{{ (page.cpg - 1) * page.limit + (scope.$index + 1) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column prop="emid" label="工号" width="100"></el-table-column>
                    <el-table-column prop="cname" fixed="left" label="中文名" width="80"></el-table-column>
                    <el-table-column prop="ename" label="英文名" width="120"></el-table-column>
                    <el-table-column prop="sex" label="性别" width="60">
                        <template #default="scope">
                            <el-tag v-if="scope.row.sex == 1">男</el-tag>

                            <el-tag v-else type="success">女</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="mz" label="民族" width="80"></el-table-column>
                    <el-table-column prop="nation" label="籍贯" width="120"></el-table-column>
                    <el-table-column prop="political" label="政治面貌" width="120">
                        <template #default="scope">
                            <el-tag>{{ dichrpoliticalData.dicDescs(scope.row.political, 'itemid', 'itemname') }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="birthshow" label="生日" width="100"></el-table-column>

                    <el-table-column prop="dept" label="部门" width="120">
                        <template #default="scope">
                            <el-tag>{{ dpList.dicDescs(scope.row.dept, 'dpid', 'dpname') }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="position" label="职位" width="180">
                        <template #default="scope">
                            <el-tag>{{ dpList.dicDescs(scope.row.position, 'dpid', 'dpname') }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="datejoined" label="入职日期" width="100"></el-table-column>

                    <el-table-column prop="regualdate" label="转正日期" width="100"></el-table-column>

                    <el-table-column prop="type" label="类型" width="120">
                        <template #default="scope">
                            <el-tag>{{ dichrtypeData.dicDescs(scope.row.type) }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="grade" label="级别" width="80">
                        <template #default="scope">
                            <el-tag>{{ dichrgradeData.dicDescs(scope.row.grade) }}</el-tag>
                        </template>
                    </el-table-column>

                    <el-table-column prop="hrstatus" label="状态" width="100">
                        <template #default="scope">
                            <el-tag>{{ dichrstatusData.dicDescs(scope.row.hrstatus) }}</el-tag>
                        </template>
                    </el-table-column>

                    <el-table-column prop="marry" label="婚姻" width="80">
                        <template #default="scope">
                            <el-tag>{{ dichrmarryData.dicDescs(scope.row.marry) }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="education" label="学历" width="100">
                        <template #default="scope">
                            <el-tag>{{ dichreducationData.dicDescs(scope.row.education) }}</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="school" label="毕业学校" width="180"></el-table-column>
                    <el-table-column prop="speciality" label="主修专业" width="120"></el-table-column>

                    <el-table-column
                        prop="ifcheckout"
                        :formatter="formatisstop"
                        width="120"
                        show-overflow-tooltip
                        label="离职状态"
                    >
                        <template #default="scope">
                            <el-tag v-if="scope.row.ifcheckout == 1" type="danger">离职</el-tag>
                            <el-tag v-else-if="scope.row.ifcheckout == 0" type="success">在职</el-tag>
                            <el-tag v-else type="warning">离职申请递交</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="reqleavedate" label="离职申请日期" width="120"></el-table-column>
                    <el-table-column prop="checkout" label="最后工作日" width="100"></el-table-column>
                    <el-table-column prop="bank1" label="银行卡号" width="180"></el-table-column>
                    <el-table-column prop="idcard" label="身份证号" width="180"></el-table-column>

                    <el-table-column prop="mtele" label="手机" width="120"></el-table-column>
                    <el-table-column prop="address" label="现居住地" width="300"></el-table-column>
                    <el-table-column prop="email" label="电子邮箱" width="200"></el-table-column>
                    <el-table-column prop="qq" label="QQ" width="120"></el-table-column>
                    <el-table-column prop="wechat" label="微信" width="120"></el-table-column>

                    <el-table-column prop="id" fixed="right" label="操作" width="120">
                        <template #default="scope">
                            <span class="butgrp">
                                <el-button
                                    size="mini"
                                    icon="el-icon-edit"
                                    @click="handleEdit(scope.$index, scope.row)"
                                ></el-button>

                                <el-button
                                    size="mini"
                                    type="danger"
                                    icon="el-icon-delete"
                                    @click="handleDelete(scope.$index, scope.row)"
                                ></el-button>
                            </span>
                        </template>
                    </el-table-column>

                    <el-table-column prop="id" label="更多" fixed="right" width="80">
                        <template #default="scope">
                            <el-dropdown trigger="click" @command="morecommand">
                                <span class="el-dropdown-link" style="cursor:pointer;">
                                    <el-tag class="el-icon-arrow-down el-icon--right el-icon-share"></el-tag>
                                </span>

                                <template #dropdown>
                                    <el-dropdown-menu>
                                        <el-dropdown-item
                                            icon="el-icon-user"
                                            @click="cmd_family(scope.$index, scope.row)"
                                        >家庭成员</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-data-line"
                                            @click="cmd_works(scope.$index, scope.row)"
                                        >职业经历</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-collection"
                                            @click="cmd_education(scope.$index, scope.row)"
                                        >教育背景</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-medal-1"
                                            @click="cmd_cert(scope.$index, scope.row)"
                                        >资质证书</el-dropdown-item>
                                        <el-dropdown-item :divided="true"></el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-receiving"
                                            @click="cmd_contract(scope.$index, scope.row)"
                                        >签订合同</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-reading"
                                            @click="cmd_passport(scope.$index, scope.row)"
                                        >办理证件</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-sort"
                                            @click="cmd_transform(scope.$index, scope.row)"
                                        >内部变动</el-dropdown-item>
                                        <el-dropdown-item :divided="true"></el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-trophy"
                                            @click="cmd_award(scope.$index, scope.row)"
                                        >奖惩管理</el-dropdown-item>
                                        <el-dropdown-item :divided="true"></el-dropdown-item>
                                        <el-dropdown-item>领用物品</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-table-lamp"
                                            @click="cmd_otlist(scope.$index, scope.row)"
                                        >加班申请</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-headset"
                                            @click="cmd_levlist(scope.$index, scope.row)"
                                        >假期申请</el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-truck"
                                            @click="cmd_expense(scope.$index, scope.row)"
                                        >报销申请</el-dropdown-item>
                                        <el-dropdown-item :divided="true"></el-dropdown-item>
                                        <el-dropdown-item
                                            icon="el-icon-position"
                                            command="commandcheckout"
                                            @click="cmd_checkout(scope.$index, scope.row)"
                                        >离职处理</el-dropdown-item>
                                    </el-dropdown-menu>
                                </template>
                            </el-dropdown>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!-- 翻页控件 -->
        <div style="margin-top:25px; ">
            <el-pagination
                background
                layout="prev, pager, next"
                :page-size="page.limit"
                @current-change="changePage"
                :current-page="cp1"
                :total="counts"
            ></el-pagination>
        </div>
        <!-- 人事表单 -->
        <div class="dialogform">
            <el-dialog title="人事信息" width="1000px" v-model="dialogFormVisible">
                <el-form
                    :rules="rules"
                    :model="form"
                    ref="form"
                    class="margin:0 20px;display:flex;"
                >
                    <el-row gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-popover
                                    placement="bottom"
                                    title="部门职位选择（选蓝色标记项目）"
                                    :width="400"
                                    trigger="manual"
                                    :visible="deptVisible"
                                >
                                    <el-tree
                                        :data="dpData"
                                        node-key="id"
                                        ref="deptTree1"
                                        :props="dpProps"
                                        :default-expand-all="true"
                                        style="overflow-x: scroll;height:600px;"
                                        @node-click="newdeptnodeclick"
                                    >
                                        <template #default="{ node, data }">
                                            <span
                                                :class="{ ispos: data.is_pos == 1 }"
                                            >{{ node.label }}</span>
                                        </template>
                                    </el-tree>
                                    <template #reference>
                                        <el-form-item
                                            label="部门/职位"
                                            prop="dpname"
                                            :label-width="formLabelWidth"
                                            @click="deptVisible = !deptVisible"
                                        >
                                            <el-input
                                                size="medium"
                                                v-model="form.dpname"
                                                autocomplete="off"
                                                readonly
                                                prefix-icon="el-icon-edit"
                                            ></el-input>
                                        </el-form-item>
                                    </template>
                                </el-popover>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item label="级别" :label-width="formLabelWidth">
                                    <el-select v-model="form.grade" placeholder="请选择" size="medium">
                                        <el-option
                                            v-for="item in dichrgradeData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="员工状态"
                                    :label-width="formLabelWidth"
                                    prop="hrstatus"
                                >
                                    <el-select v-model="form.hrstatus" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichrstatusData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="员工类型"
                                    :label-width="formLabelWidth"
                                    prop="type"
                                >
                                    <el-select v-model="form.type" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichrtypeData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="入职日期"
                                    :label-width="formLabelWidth"
                                    prop="datejoined"
                                >
                                    <el-date-picker
                                        v-model="form.datejoined"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="转正日期"
                                    :label-width="formLabelWidth"
                                    prop="regulardate"
                                >
                                    <el-date-picker
                                        v-model="form.regulardate"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="银行卡号"
                                    :label-width="formLabelWidth"
                                    prop="bank1"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.bank1"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="更衣箱号" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.lockid"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="入职前工龄（月份数）" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.serveryear"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item label="员工来源" :label-width="formLabelWidth">
                                    <el-select
                                        v-model="form.source"
                                        placeholder="请选择"
                                        size="medium"
                                    >
                                        <el-option
                                            v-for="item in dichrsurData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item label="工作地" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.locate"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="档案号码" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.profileno"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="工号" :label-width="formLabelWidth" prop="emid">
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.emid"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="中文名"
                                    :label-width="formLabelWidth"
                                    prop="cname"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.cname"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="英文名" :label-width="formLabelWidth">
                                    <el-input size="medium" v-model="form.ename" autocomplete="off"></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="身份证号"
                                    :label-width="formLabelWidth"
                                    prop="idcard"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.idcard"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="性别" :label-width="formLabelWidth" prop="sex">
                                    <el-switch
                                        v-model="form.sex"
                                        active-color="#13ce66"
                                        inactive-color="#409EFF"
                                        active-text="女"
                                        inactive-text="男"
                                        active-value="0"
                                        inactive-value="1"
                                    ></el-switch>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="生日" :label-width="formLabelWidth">
                                    <el-date-picker
                                        v-model="form.birth"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="婚况" :label-width="formLabelWidth" prop="marry">
                                    <el-select v-model="form.marry" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichrmarryData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="籍贯" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.nation"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="民族" :label-width="formLabelWidth">
                                    <el-input size="medium" v-model="form.mz" autocomplete="off"></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="学历" :label-width="formLabelWidth">
                                    <el-select v-model="form.education" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichreducationData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="毕业院校"
                                    :label-width="formLabelWidth"
                                    prop="school"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.school"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="主修专业" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.speciality"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="政治面貌" :label-width="formLabelWidth">
                                    <el-select v-model="form.political" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichrpoliticalData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item label="电子邮箱" :label-width="formLabelWidth">
                                    <el-input size="medium" v-model="form.email" autocomplete="off"></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="QQ" :label-width="formLabelWidth" prop="qq">
                                    <el-input size="medium" v-model="form.qq" autocomplete="off"></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="微信" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.wechat"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="电话" :label-width="formLabelWidth" prop="mtele">
                                    <el-input size="medium" v-model="form.mtele" autocomplete="off"></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="居住地址" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.address"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="有无试用期？" :label-width="formLabelWidth">
                                    <el-switch
                                        v-model="form.if_proba"
                                        active-text="有"
                                        inactive-text="否"
                                        active-value="true"
                                        inactive-value="false"
                                    ></el-switch>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="试用期从" :label-width="formLabelWidth">
                                    <el-date-picker
                                        v-model="form.probafrom"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="试用期到"
                                    :label-width="formLabelWidth"
                                    prop="probato"
                                >
                                    <el-date-picker
                                        v-model="form.probato"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="试用期工资"
                                    :label-width="formLabelWidth"
                                    prop="prosalary"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.prosalary"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="合同类型"
                                    :label-width="formLabelWidth"
                                    prop="contype"
                                >
                                    <el-select v-model="form.contype" placeholder="请选择">
                                        <el-option
                                            v-for="item in diccontypeData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="合同开始" :label-width="formLabelWidth">
                                    <el-date-picker
                                        v-model="form.confrom"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="合同结束" :label-width="formLabelWidth">
                                    <el-date-picker
                                        v-model="form.conto"
                                        type="date"
                                        placeholder="选择日期"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="合同工资"
                                    :label-width="formLabelWidth"
                                    prop="consalary"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.consalary"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>

                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="当前工资"
                                    :label-width="formLabelWidth"
                                    prop="currsalary"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.currsalary"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item label="社保账号" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.socialid"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="社保基数"
                                    :label-width="formLabelWidth"
                                    prop="socialbase"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.socialbase"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="公积金基数"
                                    :label-width="formLabelWidth"
                                    prop="housefund"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.housefund"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">人事选项信息</i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div style="display:block;width:960px;">
                                <el-checkbox-group
                                    v-model="hrcheckedshow"
                                    style="display:flex; flex-wrap:wrap;"
                                >
                                    <el-checkbox
                                        v-for="item in dichrcheckedData"
                                        :key="item.itemid"
                                        :value="item.itemname"
                                        :label="item.itemid"
                                        style="width:210px;text-align:left;"
                                    >{{ item.itemname }}</el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="紧急联系人"
                                    :label-width="formLabelWidth"
                                    prop="jjname"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.jjname"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="关系" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.jjrelation"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="联系电话"
                                    :label-width="formLabelWidth"
                                    prop="jjtele"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.jjtele"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="联系地址" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.jjaddress"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline"></i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="户口类型"
                                    :label-width="formLabelWidth"
                                    prop="hktype"
                                >
                                    <el-select v-model="form.hktype" placeholder="请选择">
                                        <el-option
                                            v-for="item in dichktypeData "
                                            :key="item.itemid"
                                            :label="item.itemname"
                                            :value="item.itemid"
                                        ></el-option>
                                    </el-select>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="户口地址" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.hkaddress"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="户口所属地" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.hkfield"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20"></el-row>

                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
        <!-- 离职表单 -->
        <div class="dialogform">
            <el-dialog title="离职信息" width="1000px" v-model="dialogCheckoutVisible">
                <el-form
                    :rules="checkoutrules"
                    :model="form"
                    ref="checkoutform"
                    class="margin:0 20px;display:flex;"
                >
                    <el-row gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="申请日期"
                                    :label-width="formLabelWidth"
                                    prop="reqleavedate"
                                >
                                    <el-date-picker
                                        v-model="form.reqleavedate"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="最后工作日"
                                    :label-width="formLabelWidth"
                                    prop="lastdate"
                                >
                                    <el-date-picker
                                        v-model="form.lastdate"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="离职日期"
                                    :label-width="formLabelWidth"
                                    prop="checkout"
                                >
                                    <el-date-picker
                                        v-model="form.checkout"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="结余年假（小时数）"
                                    :label-width="formLabelWidth"
                                    prop="alhoursm"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.alhoursm"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="年假到期日"
                                    :label-width="formLabelWidth"
                                    prop="aledate"
                                >
                                    <el-date-picker
                                        v-model="form.aledate"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>

                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="结余积假（小时数）"
                                    :label-width="formLabelWidth"
                                    prop="acclhoursm"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.acclhoursm"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="积假到期日"
                                    :label-width="formLabelWidth"
                                    prop="accledate"
                                >
                                    <el-date-picker
                                        v-model="form.accledate"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>

                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">离职选项信息</i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div style="display:block;width:960px;">
                                <el-checkbox-group
                                    v-model="form.checkoutchecked"
                                    style="display:flex; flex-wrap:wrap;"
                                >
                                    <el-checkbox
                                        v-for="item in checkoutcheckedData"
                                        :key="item.itemid"
                                        :value="item.itemname"
                                        :label="item.itemid"
                                        style="width:210px;text-align:left;"
                                    >{{ item.itemname }}</el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-col>
                    </el-row>

                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">离职类型</i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div style="display:block;width:960px;">
                                <el-checkbox-group
                                    v-model="form.checkouttype"
                                    style="display:flex; flex-wrap:wrap;"
                                >
                                    <el-checkbox
                                        v-for="item in checkouttypeData"
                                        :key="item.itemid"
                                        :value="item.itemname"
                                        :label="item.itemid"
                                        style="width:210px;text-align:left;"
                                    >{{ item.itemname }}</el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">离职原因</i>
                    </el-divider>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div style="display:block;width:960px;">
                                <el-checkbox-group
                                    v-model="form.checkoutreason"
                                    style="display:flex; flex-wrap:wrap;"
                                >
                                    <el-checkbox
                                        v-for="item in checkoutreasonData"
                                        :key="item.itemid"
                                        :value="item.itemname"
                                        :label="item.itemid"
                                        style="width:210px;text-align:left;"
                                    >{{ item.itemname }}</el-checkbox>
                                </el-checkbox-group>
                            </div>
                        </el-col>
                    </el-row>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">其他离职信息</i>
                    </el-divider>
                    <el-form-item label="离职信息备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.checkoutremark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="savecheckoutForm(0)">撤销离职</el-button>
                        <el-button @click="dialogCheckoutVisible = false">取 消</el-button>
                        <el-button type="primary" @click="savecheckoutForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
        <!-- 家庭成员表单 -->
        <div class="dialogform">
            <el-dialog title="家庭成员" width="1000px" v-model="dialogFamilyVisible">
                <el-form
                    :rules="familyrules"
                    :model="familyform"
                    ref="familyform"
                    class="margin:0 20px;display:flex;"
                >
                    <el-row gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="姓名" :label-width="formLabelWidth" prop="name">
                                    <el-input
                                        size="medium"
                                        v-model="familyform.name"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="关系"
                                    :label-width="formLabelWidth"
                                    prop="relation"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="familyform.relation"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="身份证" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="familyform.idcard"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="出生日期"
                                    :label-width="formLabelWidth"
                                    prop="datejoined"
                                >
                                    <el-date-picker
                                        v-model="familyform.birth"
                                        type="date"
                                        placeholder="选择日期"
                                        format="YYYY-MM-DD"
                                    ></el-date-picker>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="联系电话"
                                    :label-width="formLabelWidth"
                                    prop="mtele"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="familyform.mtele"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="工作单位"
                                    :label-width="formLabelWidth"
                                    prop="company"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="familyform.company"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>

                    <el-row :gutter="20"></el-row>

                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="familyform.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button
                            type="success"
                            icon="el-icon-plus"
                            @click="changeToplus_family"
                            v-if="neworedit == false"
                        ></el-button>

                        <el-button
                            type="success"
                            @click="saveFamilyForm"
                            v-if="neworedit == true"
                        >新 增</el-button>
                        <el-button @click="dialogFamilyVisible = false">取 消</el-button>
                        <el-button
                            type="primary"
                            @click="saveFamilyForm(false)"
                            v-if="neworedit == false"
                        >保 存</el-button>
                    </span>
                </template>

                <el-divider content-position="left">
                    <i class="el-icon-edit-outline">家庭成员信息</i>
                </el-divider>

                <div style="margin-left:20px;width:100%;min-width:800px;">
                    <el-table
                        :data="familyData"
                        style="width:100%"
                        v-loading="loading"
                        element-loading-text="拼命加载中"
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        stripe
                    >
                        <el-table-column prop="name" label="姓名" fixed="left" width="100"></el-table-column>
                        <el-table-column prop="relation" label="关系" width="100"></el-table-column>

                        <el-table-column prop="mtele" label="联系电话" width="150"></el-table-column>
                        <el-table-column prop="idcard" label="身份证" width="180"></el-table-column>
                        <el-table-column prop="birth" label="出生日期" width="100"></el-table-column>

                        <el-table-column prop="company" label="工作单位" width="180"></el-table-column>
                        <el-table-column prop="remark" label="备注" width="180"></el-table-column>
                        <el-table-column prop="id" fixed="right" label="操作" width="120">
                            <template #default="scope">
                                <span class="butgrp">
                                    <el-button
                                        size="mini"
                                        icon="el-icon-edit"
                                        @click="editfamily(scope.$index, scope.row)"
                                    ></el-button>

                                    <el-button
                                        size="mini"
                                        type="danger"
                                        icon="el-icon-delete"
                                        @click="delfamily(scope.$index, scope.row)"
                                    ></el-button>
                                </span>
                            </template>
                        </el-table-column>
                    </el-table>
                </div>
            </el-dialog>
        </div>
        <!-- 职业经历 -->
        <div class="dialogform">
            <el-dialog title="职业经历" width="1000px" v-model="dialogWorksVisible">
                <works :fsysid="fsysid" @closeworksForm="closeWorksForm"></works>
            </el-dialog>
        </div>
        <!-- 学历教育 -->
        <div class="dialogform">
            <el-dialog title="教育学历" width="1000px" v-model="dialogEducationVisible">
                <education :fsysid="fsysid" @closeeducationForm="closeEducationForm"></education>
            </el-dialog>
        </div>
        <!-- 资质证书 -->
        <div class="dialogform">
            <el-dialog title="资质证书" width="1000px" v-model="dialogCertVisible">
                <cert :fsysid="fsysid" @closecertForm="closeCertForm"></cert>
            </el-dialog>
        </div>
        <!-- 签署合同 -->
        <div class="dialogform">
            <el-dialog title="签署合同" width="1000px" v-model="dialogContractVisible">
                <contract
                    :fsysid="fsysid"
                    :diccontypeData="diccontypeData"
                    @closecontractForm="closeContractForm"
                ></contract>
            </el-dialog>
        </div>
        <!-- 办理证件 -->
        <div class="dialogform">
            <el-dialog title="办理证件" width="1000px" v-model="dialogPPVisible">
                <passport
                    :fsysid="fsysid"
                    :diccerttypeData="diccerttypeData"
                    @closepassportForm="closePassportForm"
                ></passport>
            </el-dialog>
        </div>
        <!-- 内部变动 -->
        <div class="dialogform">
            <el-dialog title="内部变动" width="1000px" v-model="dialogTransformVisible">
                <transform
                    :fsysid="fsysid"
                    :hrData="hrData"
                    :dichrtypeData="dichrtypeData"
                    :dichrgradeData="dichrgradeData"
                    :dpData="dpData"
                    :dpList="dpList"
                    @closetransformForm="closeTransformForm"
                ></transform>
            </el-dialog>
        </div>
        <!-- 奖励管理 -->
        <div class="dialogform">
            <el-dialog title="奖励管理" width="1000px" v-model="dialogAwardVisible">
                <award
                    :fsysid="fsysid"
                    :diccerttypeData="diccerttypeData"
                    @closeawardForm="closeAwardForm"
                ></award>
            </el-dialog>
        </div>
        <!-- 加班管理 -->
        <div class="dialogform">
            <el-dialog title="加班管理" width="1000px" v-model="dialogOTlistVisible">
                <otlist
                    :fsysid="fsysid"
                    :diccerttypeData="diccerttypeData"
                    @closeotlistForm="closeOTlistForm"
                ></otlist>
            </el-dialog>
        </div>
        <!-- 请加管理 -->
        <div class="dialogform">
            <el-dialog title="请假管理" width="1000px" v-model="dialogLevlistVisible">
                <levlist
                    :fsysid="fsysid"
                    :diccerttypeData="diccerttypeData"
                    @closelevlistForm="closeLevlistForm"
                ></levlist>
            </el-dialog>
        </div>
        <!-- 更多查询 -->
        <div class="dialogform">
            <el-dialog title="高级查询" width="1000px" v-model="dialogMSVisible">
                <moresearch
                    :fsysid="fsysid"
                    :dichrgradeData="dichrgradeData"
                    :dichrtypeData="dichrtypeData"
                    :dichrstatusData="dichrstatusData"
                    :dichrpropsData="dichrpropsData"
                    :dichrpoliticalData="dichrpoliticalData"
                    :dplimit="dplimit"
                    @moreSearch="moreSearch"
                    @closemoresearchForm="closeMoresearchForm"
                ></moresearch>
            </el-dialog>
        </div>
    </el-container>
</template>
<script>
import { AX, chkBtdt } from '../utils/api';
import { ref } from 'vue';
import moment from 'moment';
import works from '../components/works'
import education from '../components/education'
import cert from '../components/cert'
import contract from '../components/contract'
import passport from '../components/passport'
import transform from '../components/transform'

import award from '../components/award'
import otlist from '../components/otlist'
import levlist from '../components/levlist'
import moresearch from '../components/moresearch'

export default {
    components: { works, education, cert, contract, passport, transform, award, otlist, levlist, moresearch },

    data() {
        return {
            dplimit: [],
            fsysid: '123',
            hrData: {},

            tableData: [],
            roleData: [],
            familyData: [],

            loading: false,
            deptVisible: false,

            dichrgradeData: [],
            dichrtypeData: [],
            dichrstatusData: [],
            dichreducationData: [],
            dichrmarryData: [],
            diccontypeData: [],
            dichrsurData: [],
            diccerttypeData: [],
            dichrpropsData: [],

            dichrpoliticalData: [],
            dichrcheckedData: [],

            checkoutcheckedData: [],
            checkouttypeData: [],
            checkoutreasonData: [],

            hrcheckedshow: [],
            deptChecked: [],

            dichktypeData: [],



            dpData: [],
            dpList: [],
            dpProps: {
                label: 'dpname',
                ispos: 'is_pos',
                children: 'children',
            },

            inputsearch: '',
            counts: 1,
            cp1: 1,
            formLabelWidth: "200",

            cmppwd: '',

            dialogFormVisible: false,
            dialogCheckoutVisible: false,
            dialogFamilyVisible: false,
            dialogWorksVisible: false,
            dialogEducationVisible: false,
            dialogCertVisible: false,
            dialogContractVisible: false,
            dialogPPVisible: false,
            dialogTransformVisible: false,
            dialogAwardVisible: false,
            dialogOTlistVisible: false,
            dialogLevlistVisible: false,

            dialogMSVisible: false,


            neworedit: true,


            page: {
                limit: 10,
                cpg: 1,

            },
            form: {
                sysid: ref(''),
                dpname: '',
                dept: '',
                position: '',

                hrchecked: [],




                emid: '12345',

                cname: '',
                ename: '',
                sex: '0',
                grade: '',
                type: '',
                hrstatus: '',
                datejoined: '',
                regulardate: '',
                idcard: '530102199907111555',

                mtele: '',
                qq: '',
                wechat: '',
                email: '',
                marry: '',
                education: '',

                birth: '',
                birthmonth: '',
                lockid: '',
                mz: '',
                bank1: '',
                address: '',
                political: '',
                nation: '',

                school: '',
                speciality: '',
                serveryear: '',


                //probation:'',
                if_proba: '0',
                //probationdate:'',
                //probationenddate:'',
                probafrom: '',
                probato: '',

                prosalary: '0',

                confrom: '',
                conto: '',
                contype: '',

                consalary: '0',

                currsalary: '0',

                housefund: '',
                socialbase: '',
                socialid: '',

                locate: '',
                source: '',
                jjname: '',
                jjtele: '',
                jjmtele: '',
                jjpostcode: '',
                jjrelation: '',
                jjaddress: '',

                hktype: '',
                hkaddress: '',
                hkfield: '',
                remark: '',
                profileno: '',

                //------------------------------------------------
                //离职信息
                //------------------------------------------------


                checkoutremark: '',
                reqleavedate: '',
                holdays: '0',
                reqdays: '0',
                checkout: '',
                lastdate: '',
                accledate: '',
                acclhoursm: '0',
                aledate: '',
                alhoursm: '0',
                checkoutreason: ['-1'],
                checkouttype: ['-1'],
                checkoutchecked: ['-1'],
                ifcheckout: '0',//必须是0
                //-----------------------------------------------
            },
            rules: {
                emid: [{ required: true, message: '请输入 工号', trigger: 'blur' }],
                jjname: [{ required: true, message: '请输入 紧急联系人', trigger: 'blur' }],

                jjtele: [{ required: true, message: '请输入 紧急联系人电话', trigger: 'blur' }],

                mtele: [{ required: true, message: '请输入 电话号码', trigger: 'blur' }],

                cname: [{ required: true, message: '请输入 中文名', trigger: 'blur', min: 1, max: 32 }],

                dpname: [{ required: true, message: '请输入 部门职位', trigger: 'blur' }],

                idcard: [{ required: true, message: '请输入 身份证号(18位)', trigger: 'blur', min: 15, max: 18 }],

                prosalary: [{
                    required: true, message: '请输入 试用期工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],
                consalary: [{
                    required: true, message: '请输入 合同工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],
                currsalary: [{
                    required: true, message: '请输入 当前工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],
                serveryear: [{
                    required: true, message: '请输入 入职前工龄月份数', trigger: 'blur', pattern: /^((0)([1-9]{1}[0-9]*))$/,
                }],
                housefund: [{
                    required: true, message: '请输入 公积金基数', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],
                socialbase: [{
                    required: true, message: '请输入 社保基数', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                }],

            },

            checkoutrules: {

                reqleavedate: [{ required: true, message: '请输入 离职申请日期', trigger: 'blur' }],

                checkout: [{ required: true, message: '请输入 离职工作日', trigger: 'blur', }],

                lastdate: [{ required: true, message: '请输入 最后工作日', trigger: 'blur', }],

                accledate: [{ required: true, message: '请输入 积假到期日', trigger: 'blur', }],

                aledate: [{ required: true, message: '请输入 年假到期日', trigger: 'blur', }],

                acclhoursm: [{
                    required: true, message: '请输入 结余积假小时数', trigger: 'blur', pattern: /^-?(0|0\.\d*|[1-9]\d*\.?\d*)$/,//正负数
                }],

                alhoursm: [{
                    required: true, message: '请输入 结余年假小时数', trigger: 'blur', pattern: /^-?(0|0\.\d*|[1-9]\d*\.?\d*)$/,//正负数
                }],


            },
            familyform: {
                sysid: '',
                birth: '',
                idcard: '',
                remark: '',
                mtele: '',
                name: '',
                relation: '',
                company: '',
            }, familyrules: {
                name: [{ required: true, message: '请输入 家属姓名', trigger: 'blur', }],

                mtele: [{ required: true, message: '请输入 家属电话号码', trigger: 'blur', }],

            }
        }
    },
    mounted() {
        this.getdic();

    },
    methods: {

        closeWorksForm(data) {
            this.dialogWorksVisible = data;
        },
        closeEducationForm(data) {
            this.dialogEducationVisible = data;
        },
        closeCertForm(data) {
            this.dialogCertVisible = data;
        },
        closeContractForm(data) {
            this.dialogContractVisible = data;
        },
        closePassportForm(data) {
            this.dialogPPVisible = data;
        },
        closeTransformForm(data) {
            this.dialogTransformVisible = data;
        },
        closeAwardForm(data) {
            this.dialogAwardVisible = data;
        },
        closeOTlistForm(data) {
            this.dialogOTlistVisible = data;
        },
        closeLevlistForm(data) {
            this.dialogLevlistVisible = data;
        },
        closeMoresearchForm(data) {
            this.dialogMSVisible = data;
        },



        init_familyform() {

            this.neworedit = true;
            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.familyform) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {
                    //   console.log('-1', item);
                    this.familyform[item] = '';
                }
            }

        },

        changeToplus_family() {
            this.init_familyform();
        },

        delfamily(idx, row) {


            this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/family/' + row.id).then((res) => {
                    if (res) {
                        this.listFamily();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editfamily(idx, row) {
            //  console.log(idx, row);
            this.neworedit = false;
            this.familyform = Object.assign({}, row);
        },

        cmd_works(idx, row) {
            this.fsysid = row.sysid;
            this.dialogWorksVisible = true;
        },
        cmd_education(idx, row) {
            this.fsysid = row.sysid;
            this.dialogEducationVisible = true;
        },
        cmd_cert(idx, row) {
            this.fsysid = row.sysid;
            this.dialogCertVisible = true;
        },
        cmd_contract(idx, row) {
            this.fsysid = row.sysid;
            this.dialogContractVisible = true;
        },
        cmd_passport(idx, row) {
            this.fsysid = row.sysid;
            this.dialogPPVisible = true;
        },
        cmd_transform(idx, row) {
            this.fsysid = row.sysid;
            this.hrData = Object.assign({}, row);
            this.dialogTransformVisible = true;
        },

        cmd_award(idx, row) {
            this.fsysid = row.sysid;
            this.dialogAwardVisible = true;
        },
        cmd_otlist(idx, row) {
            this.fsysid = row.sysid;
            this.dialogOTlistVisible = true;
        },
        cmd_levlist(idx, row) {
            this.fsysid = row.sysid;
            this.dialogLevlistVisible = true;
        },

        cmd_family(idx, row) {

            // console.log(idx, row)
            this.neworedit = true;
            AX('get', '/family/' + row.sysid).then((res) => {
                console.log(res)
                if (res) {

                    this.familyData = res.data;

                }

                this.familyform.sysid = row.sysid;
                this.dialogFamilyVisible = true;



            })



        },

        cmd_checkout(idx, row) {
            this.dialogCheckoutVisible = true;
            this.form = Object.assign({}, row);
            if (row.checkoutchecked) {
                this.form.checkoutchecked = row.checkoutchecked.split(',');
            } else {
                this.form.checkoutchecked = ['-1']
            }
            if (row.checkouttype) {
                this.form.checkouttype = row.checkouttype.split(',');
            } else { this.form.checkouttype = ['-1'] }
            if (row.checkoutreason) {
                this.form.checkoutreason = row.checkoutreason.split(',');
            } else { this.form.checkoutreason = ['-1'] }



            // console.log(idx, row)
        },
        morecommand(cmd) {

            console.log(cmd)
            //  this.form = Object.assign({}, row);
        },

        check() {

            this.deptChecked.splice('0', this.deptChecked.length);
            this.deptChecked = this.$refs.deptTree.getCheckedNodes();
        },



        newdeptnodeclick(data) {
            console.log(data)
            if (data.is_pos == 1) {
                this.deptVisible = false;
                this.form.dpname = data.dpname;
                this.form.dept = data.fid;
                this.form.position = data.dpid;
            }


        },
        test() {
            console.log('deptvisible:', this.deptVisible);
            this.deptVisible = !this.deptVisible;
        },
        handleDelete(idx, row) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/hrinfo/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },

        savecheckoutForm(ifcheckout = 1) {


            if (ifcheckout == 0) {


                /**************************************** */
                this.$confirm('此操作将永久清空离职信息, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {

                    /**
                    * ifcheckout=0 ,只要按撤销就算回到在职
                    */
                    this.form.ifcheckout = '0';
                    /**
                     * 而且需要把申请日期和离职日期清空
                     */
                    this.form.reqleavedate = null;
                    this.form.checkout = null;
                    this.form.lastdate = null;
                    this.form.accledate = null;
                    this.form.aledate = null;
                    this.form.acclhoursm = '0';
                    this.form.alhoursm = '0';
                    this.form.checkoutchecked = '';
                    this.form.checkouttype = '';
                    this.form.checkoutreason = '';
                    this.form.checkoutremark = '';

                    AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                        if (res) {

                            this.dialogCheckoutVisible = false;
                            this.listMain();
                        }
                    })
                }).catch(() => {

                    this.$message({
                        type: 'info',
                        message: '撤销完成',
                    });
                });




            }

            this.$refs.checkoutform.validate((valid) => {

                if (valid) {

                    this.form.checkoutchecked = this.form.checkoutchecked.flat().toString();
                    this.form.checkouttype = this.form.checkouttype.flat().toString();
                    this.form.checkoutreason = this.form.checkoutreason.flat().toString();

                    /**
                     * ifcheckout=1 ,只要按保存就算离职处理, 
                     * ifcheckout 0:在职，1:离职 2：离职中
                     * 需要判断。
                     */



                    this.form.ifcheckout = chkBtdt(this.form.checkout
                    )

                    AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                        if (res) {

                            this.dialogCheckoutVisible = false;
                            this.listMain();
                        }
                    })



                }
            })
        },
        saveForm() {


            console.log(this.form.datejoined)
            this.$refs.form.validate((valid) => {

                if (valid) {

                    this.form.hrchecked = this.hrcheckedshow.flat().toString();
                    this.form.birthmonth = moment(this.form.birth).format('MM');

                    if (!this.neworedit) {

                        AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }
                    else {
                        AX('post', '/hrinfo', this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }

                }
            })
        },
        saveFamilyForm() {

            this.$refs['familyform'].validate((valid) => {

                if (valid) {

                    if (!this.neworedit) {

                        AX('put', '/family/' + this.familyform.id, this.familyform).then((res) => {

                            if (res) {

                                // this.dialogFormVisible = false;
                                this.listFamily();
                                this.neworedit = false;
                            }
                        })

                    }
                    else {
                        AX('post', '/family', this.familyform).then((res) => {

                            if (res) {

                                // this.dialogFamilyVisible = false;
                                this.listFamily();

                                this.init_familyform();

                                this.neworedit = true;
                            }
                        })

                    }

                }
                console.log('this.new', this.neworedit)
            })
        },

        listFamily() {
            AX('get', '/family/' + this.familyform.sysid).then((res) => {
                console.log(res)
                if (res) {

                    this.familyData = res.data;

                }

            })


        },


        formatisstop(row) {
            return row.is_stop == 0 ? "No" : "STOP"

        },
        handleNew() {
            this.neworedit = true;
            this.dialogFormVisible = true;
            // this.getdic();
            Object.keys(this.form).forEach(key => {
                this.form[key] = '';
            });
            this.form.prosalary = 0;
            this.form.consalary = 0;
            this.form.currsalary = 0;
            this.form.sex = 1;
            this.form.if_proba = 0;
            this.form.serveryear = 0;
            this.form.housefund = 0;
            this.form.socialbase = 0;
            this.hrcheckedshow.splice(0, this.hrcheckedshow.length);

            AX('get', '/newid').then((res) => {
                this.form.emid = res.data;
            })

        },
        handleEdit(index, row) {
            //  this.getdic();
            this.neworedit = false;
            this.dialogFormVisible = true;

            this.form = Object.assign({}, row);

            //——————————————————————————————————————————————————————————————————————
            //数字或者boolean 其实都是数字，ui中的任意内容都是字符，所以需要转化
            this.form.sex = this.form.sex.toString();//数据字段是数字 smallint
            this.form.if_proba = this.form.if_proba.toString();//数据字段是真假boolean
            //——————————————————————————————————————————————————————————————————————


            this.hrcheckedshow.splice(0, this.hrcheckedshow.length);

            this.hrcheckedshow = this.form.hrchecked.split(',')


            console.log(this.form.hrcheckedshow)

            let c = 0;
            let dpname = '';
            for (let element of this.dpList) {

                if (c < 2) {
                    if (element.dpid == row.dept) {
                        dpname += element.dpname;
                        c++;
                    }
                    if (element.dpid == row.position) {
                        dpname += element.dpname;
                        c++;
                    }
                } else {
                    this.form.dpname = dpname;
                    break;
                }
            }
        },

        changePage(idx) {
            //  console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },

        getdic(type = 'hr') {
            this.loading = true;

            if (type == 'hr') {
                AX('get', '/dicm/hrgrade').then(res => {
                    this.dichrgradeData = res.data;
                    // console.log(res.data)
                    //this.showdesc(res.data, 'hrgrade_13', 'itemid', 'itemname')
                    // console.log(res.data.dicDescs('hrgrade_13'));
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrtype').then((res) => {
                    this.dichrtypeData = res.data;
                })
                    .catch(e => console.log(e.message))
                AX('get', '/dicm/hrsur').then((res) => {
                    this.dichrsurData = res.data;
                })
                    .catch(e => console.log(e.message))


                AX('get', '/dicm/contype').then((res) => {
                    this.diccontypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrchecked').then((res) => {
                    this.dichrcheckedData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hktype').then((res) => {
                    this.dichktypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/certtype').then((res) => {
                    this.diccerttypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrstatus').then((res) => {
                    this.dichrstatusData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrpolitical').then((res) => {
                    this.dichrpoliticalData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/1').then((res) => {
                    this.dichrmarryData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/5').then((res) => {
                    this.dichreducationData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dept').then((res) => {
                    this.dpData = res.data;
                    this.flattenTree(res.data);
                })
                    .catch(e => console.log(e.message))
                AX('get', '/dicm/hrprops').then((res) => {
                    this.dichrpropsData = res.data;
                })
                    .catch(e => console.log(e.message))
            }



            //      if (type == 'checkout') {

            AX('get', '/dicm/checkoutchecked').then((res) => {
                this.checkoutcheckedData = res.data;
            })
                .catch(e => console.log(e.message))


            AX('get', '/dicm/leatype').then((res) => {
                this.checkouttypeData = res.data;
            })
                .catch(e => console.log(e.message))


            AX('get', '/dicm/leareason').then((res) => {
                this.checkoutreasonData = res.data;
            })
                .catch(e => console.log(e.message))


            //        }
            this.loading = false;



        },

        async tree(data, val, id, descs) {

            if (!val) {
                return
            }
            let r = '';
            for (let item of data) {
                console.log('tree:', val, item[id])
                if (val != item[id]) {

                    if (item.children) {

                        await this.tree(item.children, val, id, descs);
                    }

                } else {
                    console.log('find.......................' + item[descs])
                    r = item[descs];
                    return item[descs];
                    //break;
                }
                break;
            }

            return r;

        },

        flattenTree(treedata) {
            for (let item of treedata) {

                let node = {};
                node.dpid = item.dpid;
                node.dpname = item.dpname;
                node.fid = item.fid;
                node.is_pos = item.is_pos;
                node.posgrade = item.posgrade;

                this.dpList.push(node);
                if (item.children) {
                    this.flattenTree(item.children);
                }

            }

        },

        cmd_moresearch() {

            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的部门！');
                return;

            } else {


                this.deptChecked.forEach(item => {
                    let dpobj = {};
                    dpobj.dpid = item.dpid;
                    this.dplimit.push(dpobj);
                });



                this.dialogMSVisible = true;
            }
        },

        moreSearch(data) {
            //console.log(data;
            this.loading = true;

            let block = encodeURI(JSON.stringify(data));

            // console.log('blockencodeURI', block.length)

            AX('get', '/hrinfo/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {



                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.tableData.forEach(item => {

                    item.birthshow = moment(item.birth).format('MM-DD')
                })

                this.loading = false;



            });

        },

        listMain() {
            //  console.log('33333333333333')



            //  let api = ''
            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的部门！');
                return;
            }

            //   console.log(this.deptChecked)
            this.loading = true;
            let block = {};

            let depts = [];

            this.deptChecked.forEach(item => {
                let dpobj = {};
                dpobj.dpid = item.dpid;
                depts.push(dpobj);
            });




            block.dept = depts;
            //console.log('block', JSON.stringify(block))
            block = encodeURI(JSON.stringify(block));

            // console.log('blockencodeURI', block.length)

            AX('get', '/hrinfo/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {



                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.tableData.forEach(item => {

                    item.birthshow = moment(item.birth).format('MM-DD');
                    //console.log(item.birthmonth)
                })
                this.loading = false;






            }
            )
        }
    }

}
</script>
<style scoped>
.dialogform {
    display: flex;
    margin: 0 0;
}
.input-with-select {
    width: 360px;
    margin-left: 10px;
}
.ispos {
    padding: 2px 6px;
    cursor: pointer;
    font-size: 14px;
}
.el-divider i {
    color: #409eff;
}
.pdmsg {
    margin-left: 1px;
    background-color: none;
    color: rgb(192, 192, 192);
    font-weight: normal;
    font-size: 12px;
}
</style>


