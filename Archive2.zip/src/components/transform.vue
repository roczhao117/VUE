<template>
    <!-- 工作表单 -->
    <div class="dialogform">
        <el-form :rules="rules" :model="form" ref="form">
            <el-row :gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="变更类型" :label-width="formLabelWidth" prop="type">
                            <el-select
                                v-model="form.type"
                                placeholder="请选择"
                                size="medium"
                                @change="transtypeChange"
                            >
                                <el-option
                                    v-for="item in dictranstypeData"
                                    :key="item.itemid"
                                    :label="item.itemname"
                                    :value="item.itemid"
                                ></el-option>
                            </el-select>
                        </el-form-item>
                    </div>
                </el-col>

                <el-col :span="6">
                    <div>
                        <el-form-item label="当前内容" :label-width="formLabelWidth" prop="from">
                            <el-input size="medium" v-model="form.from" autocomplete="off" disabled></el-input>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="变更到" :label-width="formLabelWidth" prop="to">
                            <el-popover
                                placement="bottom"
                                title
                                :width="300"
                                trigger="click"
                                :visible="deptVisible"
                            >
                                <el-tree
                                    :data="dpData"
                                    node-key="id"
                                    ref="deptTree"
                                    :props="dpProps"
                                    :default-expand-all="true"
                                    @node-click="dpNodeClick"
                                    style="overflow-x: scroll;height:600px;"
                                    v-if="form.type == 'A'"
                                >
                                    <template #default="{ node, data }">
                                        <span :class="{ ispos: data.is_pos == 1 }">{{ node.label }}</span>
                                    </template>
                                </el-tree>

                                <el-tree
                                    :data="deptpos"
                                    node-key="id"
                                    ref="deptTree"
                                    :props="dpProps"
                                    :default-expand-all="true"
                                    @node-click="posNodeClick"
                                    style="overflow-x: scroll;height:400px;"
                                    v-if="form.type == 'B'"
                                >
                                    <template #default="{ node }">
                                        <span>{{ node.label }}</span>
                                    </template>
                                </el-tree>
                                <el-tree
                                    :data="dichrgradeData"
                                    node-key="id"
                                    ref="deptTree"
                                    :props="dicProps"
                                    :default-expand-all="true"
                                    @node-click="dicNodeClick"
                                    style="overflow-x: scroll;height:400px;"
                                    v-if="form.type == 'C'"
                                >
                                    <template #default="{ node }">
                                        <span>{{ node.label }}</span>
                                    </template>
                                </el-tree>
                                <el-tree
                                    :data="dichrtypeData"
                                    node-key="id"
                                    ref="deptTree"
                                    :props="dicProps"
                                    :default-expand-all="true"
                                    @node-click="dicNodeClick"
                                    style="overflow-x: scroll;height:400px;"
                                    v-if="form.type == 'E'"
                                >
                                    <template #default="{ node }">
                                        <span>{{ node.label }}</span>
                                    </template>
                                </el-tree>

                                <template #reference>
                                    <el-input
                                        size="medium"
                                        v-model="form.to"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                        @click="to_click"
                                    ></el-input>
                                </template>
                            </el-popover>
                        </el-form-item>
                    </div>
                </el-col>

                <el-col :span="6">
                    <el-form-item label="执行日期" :label-width="formLabelWidth" prop="execdate">
                        <el-date-picker
                            v-model="form.execdate"
                            size="medium"
                            type="date"
                            placeholder="选择日期"
                            format="YYYY-MM-DD"
                        ></el-date-picker>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">内部变动</i>
                    </el-divider>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-table
                        :data="formData"
                        style="width:100%"
                        v-loading="loading"
                        element-loading-text="拼命加载中"
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        stripe
                    >
                        <el-table-column prop="type" label="类型" fixed="left" width="100">
                            <template #default="scope">
                                <el-tag>{{ dictranstypeData.dicDescs(scope.row.type) }}</el-tag>
                            </template>
                        </el-table-column>

                        <el-table-column prop="from" label="从" width="180">
                            <template #default="scope">
                                <el-tag
                                    v-if="scope.row.type == 'A'"
                                >{{ dpList.dicDescs(scope.row.from, 'dpid', 'dpname') }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'B'"
                                >{{ dpList.dicDescs(scope.row.from, 'dpid', 'dpname') }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'C'"
                                >{{ dichrgradeData.dicDescs(scope.row.from) }}</el-tag>
                                <el-tag v-if="scope.row.type == 'D'">{{ scope.row.from }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'E'"
                                >{{ dichrtypeData.dicDescs(scope.row.from) }}</el-tag>
                            </template>
                        </el-table-column>
                        <el-table-column prop="to" label="到" width="180">
                            <template #default="scope">
                                <el-tag
                                    v-if="scope.row.type == 'A'"
                                >{{ dpList.dicDescs(scope.row.to, 'dpid', 'dpname') }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'B'"
                                >{{ dpList.dicDescs(scope.row.to, 'dpid', 'dpname') }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'C'"
                                >{{ dichrgradeData.dicDescs(scope.row.to) }}</el-tag>
                                <el-tag v-if="scope.row.type == 'D'">{{ scope.row.to }}</el-tag>
                                <el-tag
                                    v-if="scope.row.type == 'E'"
                                >{{ dichrtypeData.dicDescs(scope.row.to) }}</el-tag>
                            </template>
                        </el-table-column>

                        <el-table-column prop="execdate" label="执行日期" width="150"></el-table-column>

                        <el-table-column prop="remark" label="备注" width="180"></el-table-column>
                        <el-table-column prop="id" fixed="right" label="操作" width="120">
                            <template #default="scope">
                                <span class="butgrp">
                                    <el-button
                                        size="mini"
                                        type="danger"
                                        icon="el-icon-delete"
                                        @click="delform(scope.$index, scope.row)"
                                        v-if="scope.row.passed != 1"
                                    ></el-button>
                                    <el-tag v-if="scope.row.passed == 1">已生效</el-tag>
                                </span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col
                    :span="24"
                    style="display:flex; justify-content: flex-end;padding-top:15px;"
                >
                    <el-button
                        type="success"
                        icon="el-icon-plus"
                        @click="init_form"
                        v-if="is_new == false"
                    ></el-button>

                    <el-button type="success" @click="saveform" v-if="is_new == true">新 增</el-button>
                    <el-button @click="closeform">取 消</el-button>
                    <el-button type="primary" @click="saveform" v-if="is_new == false">保 存</el-button>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>
<script>
import { AX, } from '../utils/api';
import { ref } from 'vue';


export default {

    props: {
        fsysid: {
            type: String,
            required: true
        },
        hrData: {
            type: Object,
            required: true
        },




        dichrtypeData: {
            type: Array,
            required: true
        },
        dichrgradeData: {
            type: Array,
            required: true
        },
        dpData: {
            type: Object,
            required: true
        },
        dpList: {
            type: Array,
            required: true
        },

    },

    data() {
        return {

            selfRouter: 'transform',

            formData: [],

            deptpos: [],

            loading: false,

            is_new: true,

            dialogFormVisible: false,

            deptVisible: false,

            formLabelWidth: "200",

            dictranstypeData: [],

            dpProps: {
                label: 'dpname',
                ispos: 'is_pos',
                children: 'children',
            },
            dicProps: {
                label: 'itemname',
                id: 'itemid',
                children: 'children',
            },

            form: {
                sysid: ref(''),
                type: '',
                from: '',
                to: '',
                dpet: '',
                position: '',
                execdate: '',
                fromdescs: '',
                todescs: '',
                remark: '',
            },
            rules: {

                type: [{ required: true, message: '请选择 类型', trigger: 'blur' }],

                to: [{ required: true, message: '请选择 变更到的内容', trigger: 'blur' }],

                execdate: [{ required: true, message: '请选择 执行日期', trigger: 'blur' }],

            },


        }
    },
    mounted() {
        this.getdic();
        this.listMain();
    },
    watch: {
        fsysid() {
            this.listMain()

        }
    },
    methods: {

        dpNodeClick(data) {
            if (data.is_pos == 1) {
                this.deptVisible = false;
                this.form.to = data.dpname;
                this.form.dept = data.fid;
                this.form.position = data.dpid;
            } else {
                this.$message.error('请选择绿色的职位！')
            }

        },
        posNodeClick(data) {
            this.deptVisible = false;
            this.form.to = data.dpname;
            this.form.dept = data.fid;
            this.form.position = data.dpid;
        },
        dicNodeClick(data) {
            this.deptVisible = false;
            this.form.to = data.itemname;
            this.form.dept = data.itemid;
            this.form.position = data.itemid;
        },

        to_click() {
            //如果不等一当前工资
            if (this.form.type != 'D') {
                this.deptVisible = true;
            }
        },

        transtypeChange() {
            switch (this.form.type) {
                case 'A'://部门职位

                    this.form.from = this.dpList.dicDescs(this.hrData.dept, 'dpid', 'dpname')
                        + ' [ ' + this.dpList.dicDescs(this.hrData.position, 'dpid', 'dpname') + ' ]'
                    break;
                case 'B'://职位
                    this.dpList.forEach(item => {
                        if (item.fid == this.hrData.dept) {
                            this.deptpos.push(item)

                        }
                    })
                    this.form.from = this.dpList.dicDescs(this.hrData.position, 'dpid', 'dpname')
                    break;
                case 'C'://级别
                    this.form.from = this.dichrgradeData.dicDescs(this.hrData.grade)
                    break;
                case 'D'://当前工资
                    this.form.from = this.hrData.currsalary;
                    break;
                case 'E'://录用性质
                    this.form.from = this.dichrtypeData.dicDescs(this.hrData.type)
                    break;
                default:
                    console.log(this.form.type)

            }
        },

        init_form() {


            this.is_new = true;

            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.form) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {

                    this.form[item] = '';
                }
            }

        },

        closeform() {

            this.$emit('close' + this.selfRouter + 'Form', false);

        },


        delform(idx, row) {


            this.$confirm('此操作将永久删除该人当天所有变动记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/' + this.selfRouter + '/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editform(idx, row) {
            //  console.log(idx, row);
            this.is_new = false;
            this.form = Object.assign({}, row);
        },


        saveform() {

            this.$refs.form.validate((valid) => {

                if (valid) {

                    if (this.fsysid) {
                        this.form.sysid = this.fsysid;
                        //增加部门职位
                        if (this.form.type == 'A') {
                            this.form.from = this.hrData.dept;
                            this.form.to = this.form.dept;
                            this.form.type = 'A';
                            AX('post', '/' + this.selfRouter, this.form).then((res) => {

                                if (res) {
                                    this.form.from = this.hrData.position;
                                    this.form.to = this.form.position;
                                    this.form.type = 'B';

                                    AX('post', '/' + this.selfRouter, this.form).then((res) => {
                                        if (res) {

                                            //    this.dialogFormVisible = false;
                                            this.listMain();
                                            this.init_form();
                                        }
                                    })
                                }
                            })

                        } else {

                            if (this.form.type == 'B') {
                                this.form.from = this.hrData.position;
                                this.form.to = this.form.position;

                            }

                            if (this.form.type == 'C') {
                                this.form.from = this.hrData.grade;
                                this.form.to = this.form.position;

                            }
                            if (this.form.type == 'D') {
                                this.form.from = this.hrData.currsalary;

                            }
                            if (this.form.type == 'E') {
                                this.form.from = this.hrData.type;
                                this.form.to = this.form.position;
                            }
                            AX('post', '/' + this.selfRouter, this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                    this.init_form();
                                }
                            })

                        }

                    }
                }
            })
        },

        listMain() {

            AX('get', '/' + this.selfRouter + '/' + this.fsysid).then(res => {



                this.formData = res.data;

                this.loading = false;



            }
            )
        },

        getdic() {
            AX('get', '/dicm/transtype').then((res) => {
                this.dictranstypeData = res.data;
            })
        },

    }

}
</script>
<style scoped>
.ispos {
    color: white;
    background-color: #67c23a;
    padding: 2px 6px;
    cursor: pointer;
    font-size: 12px;
    border-radius: 5px;
}
.el-divider i {
    color: #409eff;
}
</style>


