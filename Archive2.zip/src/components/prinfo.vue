<template>
    <el-container direction="vertical">
        <!-- 查询头 -->
        <div style="display:flex;margin:1px;margin-right:20px;">
            <el-tooltip content="新加员工" placement="top">
                <el-button type="primary" icon="el-icon-plus" @click="handleNew()"></el-button>
            </el-tooltip>
            <el-tooltip content="刷新数据" placement="top">
                <el-button type="primary" icon="el-icon-refresh" @click="listMain()"></el-button>
            </el-tooltip>
            <el-input
                placeholder="查询内容"
                v-model="inputsearch"
                class="input-with-select"
                v-on:keydown.enter="listMain()"
            >
                <template #append>
                    <el-button icon="el-icon-search" @click="listMain()">查询</el-button>
                </template>
            </el-input>
            <el-tooltip content="高级查询" placement="top">
                <el-button
                    type="primary"
                    icon="el-icon-view"
                    @click="cmd_moresearch"
                    style="margin-left:20px"
                ></el-button>
            </el-tooltip>
        </div>
        <!-- 人事表格子 -->
        <div style="display:flex;margin-top:10px;height:650px">
            <div style="border-right:0px solid rgb(239,239,239);margin-left:1px;">
                <el-tree
                    :data="dpData"
                    show-checkbox
                    node-key="id"
                    ref="deptTree"
                    :props="dpProps"
                    :default-expand-all="true"
                    @check="check"
                    style="width: 250px;overflow-x: scroll;height:715px;"
                >
                    <template #default="{ node, data }">
                        <span :class="{ ispos: data.is_pos == 1 }">
                            {{ node.label }}
                            <span class="pdmsg" v-if="data.is_pos == 1">职位</span>

                            <span class="pdmsg" v-else>部门</span>
                        </span>
                    </template>
                </el-tree>
            </div>
            <div style="margin-left:20px;width:100%;min-width:800px;">
                <el-table
                    :data="tableData"
                    style="width: 95%"
                    v-loading="loading"
                    element-loading-text="拼命加载中"
                    element-loading-spinner="el-icon-loading"
                    element-loading-background="rgba(0, 0, 0, 0.8)"
                    stripe
                >
                    <el-table-column prop="id" fixed width="80" type="index">
                        <template #default="scope">
                            <span>{{ (page.cpg - 1) * page.limit + (scope.$index + 1) }}</span>
                        </template>
                    </el-table-column>

                    <el-table-column prop="h.emid" label="工号" width="100"></el-table-column>
                    <el-table-column prop="h.cname" fixed="left" label="中文名" width="80"></el-table-column>
                    <el-table-column prop="h.ename" label="英文名" width="120"></el-table-column>
                    <el-table-column prop="h.sex" label="性别" width="60">
                        <template #default="scope">
                            <el-tag v-if="scope.row.sex == 1">男</el-tag>

                            <el-tag v-else type="success">女</el-tag>
                        </template>
                    </el-table-column>

                    <el-table-column prop="h.datejoined" label="入职日期" width="100"></el-table-column>

                    <el-table-column prop="h.regualdate" label="转正日期" width="100"></el-table-column>

                    <el-table-column
                        prop="h.ifcheckout"
                        :formatter="formatisstop"
                        width="120"
                        show-overflow-tooltip
                        label="离职状态"
                    >
                        <template #default="scope">
                            <el-tag v-if="scope.row.ifcheckout == 1" type="danger">离职</el-tag>
                            <el-tag v-else-if="scope.row.ifcheckout == 0" type="success">在职</el-tag>
                            <el-tag v-else type="warning">离职申请递交</el-tag>
                        </template>
                    </el-table-column>
                    <el-table-column prop="h.reqleavedate" label="离职申请日期" width="120"></el-table-column>
                    <el-table-column prop="h.checkout" label="最后工作日" width="100"></el-table-column>
                    <el-table-column prop="h.bank1" label="银行卡号" width="180"></el-table-column>
                    <el-table-column prop="h.idcard" label="身份证号" width="180"></el-table-column>

                    <el-table-column prop="h.mtele" label="手机" width="120"></el-table-column>
                    <el-table-column prop="id" fixed="right" label="操作" width="120">
                        <template #default="scope">
                            <span class="butgrp">
                                <el-button
                                    size="mini"
                                    icon="el-icon-edit"
                                    @click="handleEdit(scope.$index, scope.row)"
                                ></el-button>

                                <el-button
                                    size="mini"
                                    type="danger"
                                    icon="el-icon-delete"
                                    @click="handleDelete(scope.$index, scope.row)"
                                ></el-button>
                            </span>
                        </template>
                    </el-table-column>
                </el-table>
            </div>
        </div>
        <!-- 翻页控件 -->
        <div style="margin-top:25px; ">
            <el-pagination
                background
                layout="prev, pager, next"
                :page-size="page.limit"
                @current-change="changePage"
                :current-page="cp1"
                :total="counts"
            ></el-pagination>
        </div>
        <!-- 人事表单 -->
        <div class="dialogform">
            <el-dialog title="薪酬信息" width="1000px" v-model="dialogFormVisible">
                <el-form
                    :rules="rules"
                    :model="form"
                    ref="form"
                    class="margin:0 20px;display:flex;"
                >
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item label="工号" :label-width="formLabelWidth" prop="emid">
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.h.emid"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="中文名"
                                    :label-width="formLabelWidth"
                                    prop="cname"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.h.cname"
                                        :disabled="!neworedit"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item label="英文名" :label-width="formLabelWidth">
                                    <el-input
                                        size="medium"
                                        v-model="form.h.ename"
                                        :disabled="!neworedit"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="身份证号"
                                    :label-width="formLabelWidth"
                                    prop="idcard"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form.h.idcard"
                                        :disabled="!neworedit"
                                        autocomplete="off"
                                        prefix-icon="el-icon-edit"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="20">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="当前工资"
                                    :label-width="formLabelWidth"
                                    prop="prosalary"
                                >
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.h.currsalary"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="24">
                        <el-col :span="6" v-for="item in pritemData" :key="item.prid">
                            <div>
                                <el-form-item
                                    :label="item.prname + [item.prid]"
                                    :label-width="formLabelWidth"
                                    :prop="item.prid"
                                    :key="item.prid"
                                >
                                    <el-input
                                        size="medium"
                                        v-model="form[item.prid]"
                                        value="0.00"
                                        autocomplete="off"
                                        @input="pritemchange"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>
                    <el-row :gutter="24">
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="个保合计"
                                    :label-width="formLabelWidth"
                                    prop="prosalary"
                                >
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.s40"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="所得税"
                                    :label-width="formLabelWidth"
                                    prop="prosalary"
                                >
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.s030"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                        <el-col :span="6">
                            <div>
                                <el-form-item
                                    label="实发工资"
                                    :label-width="formLabelWidth"
                                    prop="prosalary"
                                >
                                    <el-input
                                        size="medium"
                                        :disabled="!neworedit"
                                        v-model="form.s33"
                                        autocomplete="off"
                                    ></el-input>
                                </el-form-item>
                            </div>
                        </el-col>
                    </el-row>

                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                </el-form>
                <template #footer>
                    <span class="dialog-footer">
                        <el-button @click="dialogFormVisible = false">取 消</el-button>
                        <el-button type="primary" @click="saveForm">确 定</el-button>
                    </span>
                </template>
            </el-dialog>
        </div>
    </el-container>
</template>
<script>
import { AX, chkBtdt } from '../utils/api';
import { ref } from 'vue';
import moment from 'moment';


export default {

    data() {
        return {
            dplimit: [],
            fsysid: '123',
            hrData: {},

            tableData: [],
            roleData: [],
            familyData: [],

            pritemData: [],

            loading: false,
            deptVisible: false,

            dichrgradeData: [],
            dichrtypeData: [],
            dichrstatusData: [],
            dichreducationData: [],
            dichrmarryData: [],
            diccontypeData: [],
            dichrsurData: [],
            diccerttypeData: [],
            dichrpropsData: [],

            dichrpoliticalData: [],
            dichrcheckedData: [],

            checkoutcheckedData: [],
            checkouttypeData: [],
            checkoutreasonData: [],

            hrcheckedshow: [],
            deptChecked: [],

            dichktypeData: [],



            dpData: [],
            dpList: [],
            dpProps: {
                label: 'dpname',
                ispos: 'is_pos',
                children: 'children',
            },

            inputsearch: '',
            counts: 1,
            cp1: 1,
            formLabelWidth: "200",

            cmppwd: '',

            dialogFormVisible: false,
            dialogCheckoutVisible: false,
            dialogFamilyVisible: false,
            dialogWorksVisible: false,
            dialogEducationVisible: false,
            dialogCertVisible: false,
            dialogContractVisible: false,
            dialogPPVisible: false,
            dialogTransformVisible: false,
            dialogAwardVisible: false,
            dialogOTlistVisible: false,
            dialogLevlistVisible: false,

            dialogMSVisible: false,


            neworedit: true,


            page: {
                limit: 10,
                cpg: 1,

            },
            form: {
                calperiod: '',
                fromdate: '',
                todate: '',
                s001: 0,
                s002: 0,
                s003: 0,
                s004: 0,
                s005: 0,
                s006: 0,
                s007: 0,
                s008: 0,
                s009: 0,
                s010: 0,
                s011: 0,
                s012: 0,
                s013: 0,
                s014: 0,
                s015: 0,
                s016: 0,
                s017: 0,
                s018: 0,
                s019: 0,
                s020: 0,
                s021: 0,
                s022: 0,
                s023: 0,
                s024: 0,
                s025: 0,
                s026: 0,
                s027: 0,
                s028: 0,
                s029: 0,
                s030: 0,
                s031: 0,
                s032: 0,
                s033: 0,
                s034: 0,
                s035: 0,
                s036: 0,
                s037: 0,
                s038: 0,
                s039: 0,
                s040: 0,
                s041: 0,
                s042: 0,
                s043: 0,
                s044: 0,
                s045: 0,
                s046: 0,
                s047: 0,
                s048: 0,
                s049: 0,
                s050: 0,
                s051: 0,
                s052: 0,
                s053: 0,
                s054: 0,
                s055: 0,
                s056: 0,
                s057: 0,
                s058: 0,
                s059: 0,
                s060: 0,
                s061: 0,
                s062: 0,
                s063: 0,
                s064: 0,
                s065: 0,
                s066: 0,
                s067: 0,
                s068: 0,
                s069: 0,
                s070: 0,
                s071: 0,
                s072: 0,
                s073: 0,
                s074: 0,
                s075: 0,
                s076: 0,
                s077: 0,
                s078: 0,
                s079: 0,
                s080: 0,
                s081: 0,
                s082: 0,
                s083: 0,
                s084: 0,
                s085: 0,
                s086: 0,
                s087: 0,
                s088: 0,
                s089: 0,
                s090: 0,
                s091: 0,
                s092: 0,
                s093: 0,
                s094: 0,
                s095: 0,
                s096: 0,
                s097: 0,
                s098: 0,
                s099: 0,
                s100: 0,
                s01: 0,
                s02: 0,
                s03: 0,
                s04: 0,
                s05: 0,
                s06: 0,
                s07: 0,
                s08: 0,
                s09: 0,
                s10: 0,
                s11: 0,
                s12: 0,
                s13: 0,
                s14: 0,
                s15: 0,
                s16: 0,
                s17: 0,
                s18: 0,
                s19: 0,
                s20: 0,
                s21: 0,
                s22: 0,
                s23: 0,
                s24: 0,
                s25: 0,
                s26: 0,
                s27: 0,
                s28: 0,
                s29: 0,
                s30: 0,
                s31: 0,
                s32: 0,
                s33: 0,
                s34: 0,
                s35: 0,
                s36: 0,
                s37: 0,
                s38: 0,
                s39: 0,
                s40: 0,
                s41: 0,
                s42: 0,
                s43: 0,
                s44: 0,
                s45: 0,
                s46: 0,
                s47: 0,
                s48: 0,
                s49: 0,
                s50: 0,
                s51: 0,
                s52: 0,
                s53: 0,
                s54: 0,
                s55: 0,
                s56: 0,
                s57: 0,
                s58: 0,
                s59: 0,
                s60: 0,
                s61: 0,
                s62: 0,
                s63: 0,
                s64: 0,
                s65: 0,
                s66: 0,
                s67: 0,
                s68: 0,
                s69: 0,
                s70: 0,
                s71: 0,
                s72: 0,
                s73: 0,
                s74: 0,
                s75: 0,
                s76: 0,
                s77: 0,
                s78: 0,
                s79: 0,
                s80: 0,
                s81: 0,
                s82: 0,
                s83: 0,
                s84: 0,
                s85: 0,
                s86: 0,
                s87: 0,
                s88: 0,
                s89: 0,
                s90: 0,
                s91: 0,
                s92: 0,
                s93: 0,
                s94: 0,
                s95: 0,
                s96: 0,
                s97: 0,
                s98: 0,
                s99: 0,

                h: {
                    sysid: ref(''),
                    dpname: '',
                    dept: '',
                    position: '',

                    hrchecked: [],




                    emid: '12345',

                    cname: '',
                    ename: '',
                    sex: '0',
                    grade: '',
                    type: '',
                    hrstatus: '',
                    datejoined: '',
                    regulardate: '',
                    idcard: '530102199907111555',

                    mtele: '',
                    qq: '',
                    wechat: '',
                    email: '',
                    marry: '',
                    education: '',

                    birth: '',
                    birthmonth: '',
                    lockid: '',
                    mz: '',
                    bank1: '',
                    address: '',
                    political: '',
                    nation: '',

                    school: '',
                    speciality: '',
                    serveryear: '',


                    //probation:'',
                    if_proba: '0',
                    //probationdate:'',
                    //probationenddate:'',
                    probafrom: '',
                    probato: '',

                    prosalary: '0',

                    confrom: '',
                    conto: '',
                    contype: '',

                    consalary: '0',

                    currsalary: '0',

                    housefund: '',
                    socialbase: '',
                    socialid: '',

                    locate: '',
                    source: '',
                    jjname: '',
                    jjtele: '',
                    jjmtele: '',
                    jjpostcode: '',
                    jjrelation: '',
                    jjaddress: '',

                    hktype: '',
                    hkaddress: '',
                    hkfield: '',
                    remark: '',
                    profileno: '',

                    //------------------------------------------------
                    //离职信息
                    //------------------------------------------------


                    checkoutremark: '',
                    reqleavedate: '',
                    holdays: '0',
                    reqdays: '0',
                    checkout: '',
                    lastdate: '',
                    accledate: '',
                    acclhoursm: '0',
                    aledate: '',
                    alhoursm: '0',
                    checkoutreason: ['-1'],
                    checkouttype: ['-1'],
                    checkoutchecked: ['-1'],
                    ifcheckout: '0',//必须是0
                    //-----------------------------------------------
                }
            },
            rules: {
                // emid: [{ required: true, message: '请输入 工号', trigger: 'blur' }],
                // jjname: [{ required: true, message: '请输入 紧急联系人', trigger: 'blur' }],

                // jjtele: [{ required: true, message: '请输入 紧急联系人电话', trigger: 'blur' }],

                // mtele: [{ required: true, message: '请输入 电话号码', trigger: 'blur' }],

                // cname: [{ required: true, message: '请输入 中文名', trigger: 'blur', min: 1, max: 32 }],

                // dpname: [{ required: true, message: '请输入 部门职位', trigger: 'blur' }],

                // idcard: [{ required: true, message: '请输入 身份证号(18位)', trigger: 'blur', min: 15, max: 18 }],

                // prosalary: [{
                //     required: true, message: '请输入 试用期工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                // }],
                // consalary: [{
                //     required: true, message: '请输入 合同工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                // }],
                // currsalary: [{
                //     required: true, message: '请输入 当前工资', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                // }],
                // serveryear: [{
                //     required: true, message: '请输入 入职前工龄月份数', trigger: 'blur', pattern: /^((0)([1-9]{1}[0-9]*))$/,
                // }],
                // housefund: [{
                //     required: true, message: '请输入 公积金基数', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                // }],
                // socialbase: [{
                //     required: true, message: '请输入 社保基数', trigger: 'blur', pattern: /^(0(.)?\d+|[1-9]\d*(.)?\d*)$/,
                // }],

            },

            checkoutrules: {

                reqleavedate: [{ required: true, message: '请输入 离职申请日期', trigger: 'blur' }],

                checkout: [{ required: true, message: '请输入 离职工作日', trigger: 'blur', }],

                lastdate: [{ required: true, message: '请输入 最后工作日', trigger: 'blur', }],

                accledate: [{ required: true, message: '请输入 积假到期日', trigger: 'blur', }],

                aledate: [{ required: true, message: '请输入 年假到期日', trigger: 'blur', }],

                acclhoursm: [{
                    required: true, message: '请输入 结余积假小时数', trigger: 'blur', pattern: /^-?(0|0\.\d*|[1-9]\d*\.?\d*)$/,//正负数
                }],

                alhoursm: [{
                    required: true, message: '请输入 结余年假小时数', trigger: 'blur', pattern: /^-?(0|0\.\d*|[1-9]\d*\.?\d*)$/,//正负数
                }],


            },
            familyform: {
                sysid: '',
                birth: '',
                idcard: '',
                remark: '',
                mtele: '',
                name: '',
                relation: '',
                company: '',
            }, familyrules: {
                name: [{ required: true, message: '请输入 家属姓名', trigger: 'blur', }],

                mtele: [{ required: true, message: '请输入 家属电话号码', trigger: 'blur', }],

            }
        }
    },
    computed: {
        s33() { return this.form.s015 }
    },
    mounted() {
        this.getdic();

    }, swatch: {
        form: {

            // handler(val) { val.s33 = val.s015 },
            //deep: true
        },
    },
    methods: {

        pritemchange() {

            let total =
                parseFloat(this.form.h.currsalary)
                + parseFloat(this.form.s001)
                + parseFloat(this.form.s002)
                + parseFloat(this.form.s003)
                + parseFloat(this.form.s004)
                + parseFloat(this.form.s005)
                + parseFloat(this.form.s006)
                + parseFloat(this.form.s007)
                + parseFloat(this.form.s008)
                + parseFloat(this.form.s009)
                + parseFloat(this.form.s010)
                + parseFloat(this.form.s011)
                + parseFloat(this.form.s012)
                + parseFloat(this.form.s013)
                + parseFloat(this.form.s014)
                + parseFloat(this.form.s015)
                + parseFloat(this.form.s016)
                + parseFloat(this.form.s017)
                + parseFloat(this.form.s018)
                + parseFloat(this.form.s019)
                + parseFloat(this.form.s020)
                + parseFloat(this.form.s021)
                + parseFloat(this.form.s022)
                + parseFloat(this.form.s023)
                + parseFloat(this.form.s024)
                + parseFloat(this.form.s025)
                + parseFloat(this.form.s026)
                + parseFloat(this.form.s027)
                + parseFloat(this.form.s028)
                + parseFloat(this.form.s029)
                + parseFloat(this.form.s031)
                + parseFloat(this.form.s032)
                + parseFloat(this.form.s033)
                + parseFloat(this.form.s034)
                + parseFloat(this.form.s035)
                + parseFloat(this.form.s036)
                + parseFloat(this.form.s037)
                + parseFloat(this.form.s038)
                + parseFloat(this.form.s039)
                + parseFloat(this.form.s040)
                + parseFloat(this.form.s041)
                + parseFloat(this.form.s042)
                + parseFloat(this.form.s043)
                + parseFloat(this.form.s044)
                + parseFloat(this.form.s045)
                + parseFloat(this.form.s046)
                + parseFloat(this.form.s047)
                + parseFloat(this.form.s048)
                + parseFloat(this.form.s049)
                + parseFloat(this.form.s050)
                + parseFloat(this.form.s051)
                + parseFloat(this.form.s052)
                + parseFloat(this.form.s053)
                + parseFloat(this.form.s054)
                + parseFloat(this.form.s055)
                + parseFloat(this.form.s056)
                + parseFloat(this.form.s057)
                + parseFloat(this.form.s058)
                + parseFloat(this.form.s059)
                + parseFloat(this.form.s060)
                + parseFloat(this.form.s061)
                + parseFloat(this.form.s062)
                + parseFloat(this.form.s063)
                + parseFloat(this.form.s064)
                + parseFloat(this.form.s065)
                + parseFloat(this.form.s066)
                + parseFloat(this.form.s067)
                + parseFloat(this.form.s068)
                + parseFloat(this.form.s069)
                + parseFloat(this.form.s070)
                + parseFloat(this.form.s071)
                + parseFloat(this.form.s072)
                + parseFloat(this.form.s073)
                + parseFloat(this.form.s074)
                + parseFloat(this.form.s075)
                + parseFloat(this.form.s076)
                + parseFloat(this.form.s077)
                + parseFloat(this.form.s078)
                + parseFloat(this.form.s079)
                + parseFloat(this.form.s080)
                + parseFloat(this.form.s081)
                + parseFloat(this.form.s082)
                + parseFloat(this.form.s083)
                + parseFloat(this.form.s084)
                + parseFloat(this.form.s085)
                + parseFloat(this.form.s086)
                + parseFloat(this.form.s087)
                + parseFloat(this.form.s088)
                + parseFloat(this.form.s089)
                + parseFloat(this.form.s090)
                + parseFloat(this.form.s091)
                + parseFloat(this.form.s092)
                + parseFloat(this.form.s093)
                + parseFloat(this.form.s094)
                + parseFloat(this.form.s095)
                + parseFloat(this.form.s096)
                + parseFloat(this.form.s097)
                + parseFloat(this.form.s098)
                + parseFloat(this.form.s099)
                + parseFloat(this.form.s100)
                + parseFloat(this.form.s01)
                + parseFloat(this.form.s02)
                + parseFloat(this.form.s03)
                + parseFloat(this.form.s04)
                + parseFloat(this.form.s05)
                + parseFloat(this.form.s06)
                + parseFloat(this.form.s07)
                + parseFloat(this.form.s08)
                + parseFloat(this.form.s09)
                + parseFloat(this.form.s10)
                + parseFloat(this.form.s11)
                + parseFloat(this.form.s12)
                + parseFloat(this.form.s13)
                + parseFloat(this.form.s14)
                + parseFloat(this.form.s15)
                + parseFloat(this.form.s16)
                + parseFloat(this.form.s17)
                + parseFloat(this.form.s18)
                + parseFloat(this.form.s19)
                + parseFloat(this.form.s20)
                + parseFloat(this.form.s21)
                + parseFloat(this.form.s22)
                + parseFloat(this.form.s23)
                + parseFloat(this.form.s24)
                + parseFloat(this.form.s25)
                + parseFloat(this.form.s26)
                + parseFloat(this.form.s27)
                + parseFloat(this.form.s28)
                + parseFloat(this.form.s29)
                + parseFloat(this.form.s30)
                + parseFloat(this.form.s31)
                + parseFloat(this.form.s32)
                + parseFloat(this.form.s34)
                + parseFloat(this.form.s35)
                + parseFloat(this.form.s36)
                + parseFloat(this.form.s37)
                + parseFloat(this.form.s38)
                + parseFloat(this.form.s39)
                + parseFloat(this.form.s41)
                + parseFloat(this.form.s42)
                + parseFloat(this.form.s43)
                + parseFloat(this.form.s44)
                + parseFloat(this.form.s45)
                + parseFloat(this.form.s46)
                + parseFloat(this.form.s47)
                + parseFloat(this.form.s48)
                + parseFloat(this.form.s49)
                + parseFloat(this.form.s50)
                + parseFloat(this.form.s51)
                + parseFloat(this.form.s52)
                + parseFloat(this.form.s53)
                + parseFloat(this.form.s54)
                + parseFloat(this.form.s55)
                + parseFloat(this.form.s56)
                + parseFloat(this.form.s57)
                + parseFloat(this.form.s58)
                + parseFloat(this.form.s59)
                + parseFloat(this.form.s60)
                + parseFloat(this.form.s61)
                + parseFloat(this.form.s62)
                + parseFloat(this.form.s63)
                + parseFloat(this.form.s64)
                + parseFloat(this.form.s65)
                + parseFloat(this.form.s66)
                + parseFloat(this.form.s67)
                + parseFloat(this.form.s68)
                + parseFloat(this.form.s69)
                + parseFloat(this.form.s70)
                + parseFloat(this.form.s71)
                + parseFloat(this.form.s72)
                + parseFloat(this.form.s73)
                + parseFloat(this.form.s74)
                + parseFloat(this.form.s75)
                + parseFloat(this.form.s76)
                + parseFloat(this.form.s77)
                + parseFloat(this.form.s78)
                + parseFloat(this.form.s79)
                + parseFloat(this.form.s80)
                + parseFloat(this.form.s81)
                + parseFloat(this.form.s82)
                + parseFloat(this.form.s83)
                + parseFloat(this.form.s84)
                + parseFloat(this.form.s85)
                + parseFloat(this.form.s86)
                + parseFloat(this.form.s87)
                + parseFloat(this.form.s88)
                + parseFloat(this.form.s89)
                + parseFloat(this.form.s90)
                + parseFloat(this.form.s91)
                + parseFloat(this.form.s92)
                + parseFloat(this.form.s93)
                + parseFloat(this.form.s94)
                + parseFloat(this.form.s95)
                + parseFloat(this.form.s96)
                + parseFloat(this.form.s97)
                + parseFloat(this.form.s98)
                + parseFloat(this.form.s99);

            this.form.s40 = total * 0.11;
            this.form.s030 = (total - this.form.s40) * 0.15;
            this.form.s33 = total - this.form.s040 - this.form.s030;
        },



        init_familyform() {

            this.neworedit = true;
            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.familyform) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {
                    //   console.log('-1', item);
                    this.familyform[item] = '';
                }
            }

        },

        changeToplus_family() {
            this.init_familyform();
        },

        delfamily(idx, row) {


            this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/family/' + row.id).then((res) => {
                    if (res) {
                        this.listFamily();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editfamily(idx, row) {
            //  console.log(idx, row);
            this.neworedit = false;
            this.familyform = Object.assign({}, row);
        },


        cmd_family(idx, row) {

            // console.log(idx, row)
            this.neworedit = true;
            AX('get', '/family/' + row.sysid).then((res) => {
                console.log(res)
                if (res) {

                    this.familyData = res.data;

                }

                this.familyform.sysid = row.sysid;
                this.dialogFamilyVisible = true;



            })



        },

        cmd_checkout(idx, row) {
            this.dialogCheckoutVisible = true;
            this.form = Object.assign({}, row);
            if (row.checkoutchecked) {
                this.form.checkoutchecked = row.checkoutchecked.split(',');
            } else {
                this.form.checkoutchecked = ['-1']
            }
            if (row.checkouttype) {
                this.form.checkouttype = row.checkouttype.split(',');
            } else { this.form.checkouttype = ['-1'] }
            if (row.checkoutreason) {
                this.form.checkoutreason = row.checkoutreason.split(',');
            } else { this.form.checkoutreason = ['-1'] }



            // console.log(idx, row)
        },
        morecommand(cmd) {

            console.log(cmd)
            //  this.form = Object.assign({}, row);
        },

        check() {

            this.deptChecked.splice('0', this.deptChecked.length);
            this.deptChecked = this.$refs.deptTree.getCheckedNodes();
        },



        newdeptnodeclick(data) {
            console.log(data)
            if (data.is_pos == 1) {
                this.deptVisible = false;
                this.form.dpname = data.dpname;
                this.form.dept = data.fid;
                this.form.position = data.dpid;
            }


        },
        test() {
            console.log('deptvisible:', this.deptVisible);
            this.deptVisible = !this.deptVisible;
        },
        handleDelete(idx, row) {
            this.$confirm('此操作将永久删除该文件, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/hrinfo/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });
        },

        savecheckoutForm(ifcheckout = 1) {


            if (ifcheckout == 0) {


                /**************************************** */
                this.$confirm('此操作将永久清空离职信息, 是否继续?', '提示', {
                    confirmButtonText: '确定',
                    cancelButtonText: '取消',
                    type: 'warning'
                }).then(() => {

                    /**
                    * ifcheckout=0 ,只要按撤销就算回到在职
                    */
                    this.form.ifcheckout = '0';
                    /**
                     * 而且需要把申请日期和离职日期清空
                     */
                    this.form.reqleavedate = null;
                    this.form.checkout = null;
                    this.form.lastdate = null;
                    this.form.accledate = null;
                    this.form.aledate = null;
                    this.form.acclhoursm = '0';
                    this.form.alhoursm = '0';
                    this.form.checkoutchecked = '';
                    this.form.checkouttype = '';
                    this.form.checkoutreason = '';
                    this.form.checkoutremark = '';

                    AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                        if (res) {

                            this.dialogCheckoutVisible = false;
                            this.listMain();
                        }
                    })
                }).catch(() => {

                    this.$message({
                        type: 'info',
                        message: '撤销完成',
                    });
                });




            }

            this.$refs.checkoutform.validate((valid) => {

                if (valid) {

                    this.form.checkoutchecked = this.form.checkoutchecked.flat().toString();
                    this.form.checkouttype = this.form.checkouttype.flat().toString();
                    this.form.checkoutreason = this.form.checkoutreason.flat().toString();

                    /**
                     * ifcheckout=1 ,只要按保存就算离职处理, 
                     * ifcheckout 0:在职，1:离职 2：离职中
                     * 需要判断。
                     */



                    this.form.ifcheckout = chkBtdt(this.form.checkout
                    )

                    AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                        if (res) {

                            this.dialogCheckoutVisible = false;
                            this.listMain();
                        }
                    })



                }
            })
        },
        saveForm() {


            console.log(this.form.datejoined)
            this.$refs.form.validate((valid) => {

                if (valid) {

                    this.form.hrchecked = this.hrcheckedshow.flat().toString();
                    this.form.birthmonth = moment(this.form.birth).format('MM');

                    if (!this.neworedit) {

                        AX('put', '/hrinfo/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }
                    else {
                        AX('post', '/hrinfo', this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                            }
                        })

                    }

                }
            })
        },
        saveFamilyForm() {

            this.$refs['familyform'].validate((valid) => {

                if (valid) {

                    if (!this.neworedit) {

                        AX('put', '/family/' + this.familyform.id, this.familyform).then((res) => {

                            if (res) {

                                // this.dialogFormVisible = false;
                                this.listFamily();
                                this.neworedit = false;
                            }
                        })

                    }
                    else {
                        AX('post', '/family', this.familyform).then((res) => {

                            if (res) {

                                // this.dialogFamilyVisible = false;
                                this.listFamily();

                                this.init_familyform();

                                this.neworedit = true;
                            }
                        })

                    }

                }
                console.log('this.new', this.neworedit)
            })
        },

        listFamily() {
            AX('get', '/family/' + this.familyform.sysid).then((res) => {
                console.log(res)
                if (res) {

                    this.familyData = res.data;

                }

            })


        },


        formatisstop(row) {
            return row.is_stop == 0 ? "No" : "STOP"

        },
        handleNew() {
            this.neworedit = true;
            this.dialogFormVisible = true;
            // this.getdic();
            Object.keys(this.form).forEach(key => {
                this.form[key] = '';
            });
            this.form.prosalary = 0;
            this.form.consalary = 0;
            this.form.currsalary = 0;
            this.form.sex = 1;
            this.form.if_proba = 0;
            this.form.serveryear = 0;
            this.form.housefund = 0;
            this.form.socialbase = 0;
            this.hrcheckedshow.splice(0, this.hrcheckedshow.length);

            AX('get', '/newid').then((res) => {
                this.form.emid = res.data;
            })

        },
        handleEdit(index, row) {
            //  this.getdic();
            this.neworedit = false;
            this.dialogFormVisible = true;

            this.form = Object.assign({}, row);

            //——————————————————————————————————————————————————————————————————————
            //数字或者boolean 其实都是数字，ui中的任意内容都是字符，所以需要转化
            this.form.sex = this.form.sex.toString();//数据字段是数字 smallint
            this.form.if_proba = this.form.if_proba.toString();//数据字段是真假boolean
            //——————————————————————————————————————————————————————————————————————


            this.hrcheckedshow.splice(0, this.hrcheckedshow.length);

            this.hrcheckedshow = this.form.hrchecked.split(',')


            console.log(this.form.hrcheckedshow)

            let c = 0;
            let dpname = '';
            for (let element of this.dpList) {

                if (c < 2) {
                    if (element.dpid == row.dept) {
                        dpname += element.dpname;
                        c++;
                    }
                    if (element.dpid == row.position) {
                        dpname += element.dpname;
                        c++;
                    }
                } else {
                    this.form.dpname = dpname;
                    break;
                }
            }
        },

        changePage(idx) {
            //  console.log(idx)
            this.page.cpg = idx;
            this.listMain();
        },

        getdic(type = 'hr') {
            this.loading = true;

            if (type == 'hr') {
                AX('get', '/dicm/hrgrade').then(res => {
                    this.dichrgradeData = res.data;
                    // console.log(res.data)
                    //this.showdesc(res.data, 'hrgrade_13', 'itemid', 'itemname')
                    // console.log(res.data.dicDescs('hrgrade_13'));
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrtype').then((res) => {
                    this.dichrtypeData = res.data;
                })
                    .catch(e => console.log(e.message))
                AX('get', '/dicm/hrsur').then((res) => {
                    this.dichrsurData = res.data;
                })
                    .catch(e => console.log(e.message))


                AX('get', '/dicm/contype').then((res) => {
                    this.diccontypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrchecked').then((res) => {
                    this.dichrcheckedData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hktype').then((res) => {
                    this.dichktypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/certtype').then((res) => {
                    this.diccerttypeData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrstatus').then((res) => {
                    this.dichrstatusData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/hrpolitical').then((res) => {
                    this.dichrpoliticalData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/1').then((res) => {
                    this.dichrmarryData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dicm/5').then((res) => {
                    this.dichreducationData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/dept').then((res) => {
                    this.dpData = res.data;
                    this.flattenTree(res.data);
                })
                    .catch(e => console.log(e.message))
                AX('get', '/dicm/hrprops').then((res) => {
                    this.dichrpropsData = res.data;
                })
                    .catch(e => console.log(e.message))

                AX('get', '/pritemlst').then((res) => {
                    this.pritemData = res.data;
                })
                    .catch(e => console.log(e.message))




            }



            if (type == 'checkout') {

                AX('get', '/dicm/checkoutchecked').then((res) => {
                    this.checkoutcheckedData = res.data;
                })
                    .catch(e => console.log(e.message))


                AX('get', '/dicm/leatype').then((res) => {
                    this.checkouttypeData = res.data;
                })
                    .catch(e => console.log(e.message))


                AX('get', '/dicm/leareason').then((res) => {
                    this.checkoutreasonData = res.data;
                })
                    .catch(e => console.log(e.message))


            }
            this.loading = false;



        },

        async tree(data, val, id, descs) {

            if (!val) {
                return
            }
            let r = '';
            for (let item of data) {
                console.log('tree:', val, item[id])
                if (val != item[id]) {

                    if (item.children) {

                        await this.tree(item.children, val, id, descs);
                    }

                } else {
                    console.log('find.......................' + item[descs])
                    r = item[descs];
                    return item[descs];
                    //break;
                }
                break;
            }

            return r;

        },

        flattenTree(treedata) {
            for (let item of treedata) {

                let node = {};
                node.dpid = item.dpid;
                node.dpname = item.dpname;
                node.fid = item.fid;
                node.is_pos = item.is_pos;
                node.posgrade = item.posgrade;

                this.dpList.push(node);
                if (item.children) {
                    this.flattenTree(item.children);
                }

            }

        },

        cmd_moresearch() {

            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的部门！');
                return;

            } else {


                this.deptChecked.forEach(item => {
                    let dpobj = {};
                    dpobj.dpid = item.dpid;
                    this.dplimit.push(dpobj);
                });



                this.dialogMSVisible = true;
            }
        },

        moreSearch(data) {
            //console.log(data;
            this.loading = true;

            let block = encodeURI(JSON.stringify(data));

            // console.log('blockencodeURI', block.length)

            AX('get', '/hrinfo/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {



                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.tableData.forEach(item => {

                    item.birthshow = moment(item.birth).format('MM-DD')
                })

                this.loading = false;



            });

        },

        listMain() {
            //  console.log('33333333333333')



            //  let api = ''
            if (this.deptChecked.length < 1) {
                this.$message.error('请选择需要查询的部门！');
                return;
            }

            //   console.log(this.deptChecked)
            this.loading = true;
            let block = {};

            let depts = [];

            this.deptChecked.forEach(item => {
                let dpobj = {};
                dpobj.dpid = item.dpid;
                depts.push(dpobj);
            });




            block.dept = depts;
            //console.log('block', JSON.stringify(block))
            block = encodeURI(JSON.stringify(block));

            // console.log('blockencodeURI', block.length)

            AX('get', '/prstaff/' + this.page.limit + '/' + this.page.cpg + '/' + block + '/' + this.inputsearch).then(res => {


                this.tableData = res.data.rows;
                this.counts = res.data.count;

                this.tableData.forEach(item => {

                    console.log(item.h.birth)

                })

                this.loading = false;


            }
            )
        }
    }

}
</script>
<style scoped>
.dialogform {
    display: flex;
    margin: 0 0;
}
.input-with-select {
    width: 360px;
    margin-left: 10px;
}
.ispos {
    padding: 2px 6px;
    cursor: pointer;
    font-size: 14px;
}
.el-divider i {
    color: #409eff;
}
.pdmsg {
    margin-left: 1px;
    background-color: none;
    color: rgb(192, 192, 192);
    font-weight: normal;
    font-size: 12px;
}
</style>


