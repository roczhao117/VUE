<template>
    <div class="cominfo">
        <el-form
            ref="form"
            :rules="rules"
            :model="form"
            label-width="80px"
            :label-position="left"
            @submit.prevent="saveform"
        >
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="公司名称" prop="comname" style="width: 100%">
                        <el-input v-model="form.comname"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="企业信用" prop="comid">
                        <el-input v-model="form.comid"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="8">
                    <el-form-item label="开户银行" prop="bank">
                        <el-input v-model="form.bank"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="银行账号" prop="bankaccount">
                        <el-input v-model="form.bankaccount"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="邮寄地址" prop="address">
                        <el-input v-model="form.address"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="8">
                    <el-form-item label="联系人">
                        <el-input v-model="form.contacts"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="联系电话">
                        <el-input v-model="form.tele"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="8">
                    <el-form-item label="电子邮箱">
                        <el-input v-model="form.email"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="12">
                    <el-tooltip placement="top">
                        <template #content>
                            数字0：表示自然月份 （月头1号到月尾）
                            <br />数字2-28:表示跨月，数字表示开始日（比如数字21，表示周期为上月21日，到本月20日）。
                        </template>
                        <el-form-item label="薪资周期" prop="salperiod">
                            <el-input v-model="form.salperiod"></el-input>
                        </el-form-item>
                    </el-tooltip>
                </el-col>

                <el-col :span="12">
                    <el-tooltip placement="top">
                        <template #content>
                            数字0：表示自然月份 （月头1号到月尾）
                            <br />数字2-28:表示跨月，数字表示开始日（比如数字21，表示周期为这上月21日，到本月20日）。
                        </template>
                        <el-form-item label="考勤周期" prop="kqperiod">
                            <el-input v-model="form.kqperiod"></el-input>
                        </el-form-item>
                    </el-tooltip>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="12">
                    <el-form-item label="当前年度" prop="sysyear">
                        <el-input v-model="form.sysyear"></el-input>
                    </el-form-item>
                </el-col>
                <el-col :span="12">
                    <el-form-item label="当前月度" prop="sysmonth">
                        <el-input v-model="form.sysmonth"></el-input>
                    </el-form-item>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item>
                        <el-button type="primary" @click="saveform">立即创建</el-button>
                        <el-button>取消</el-button>
                    </el-form-item>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>


<script>
import { AX } from '../utils/api'
export default {
    data() {
        return {
            data: [],
            form: {
                id: '',
                name: '',
                reamrk: '',
                sort: '',
                type: '',
                comid: '',
                comname: '',
                bank: '',
                bankaccount: '',
                address: '',
                contacts: '',
                tele: '',
                email: '',
                website: '',
                salperiod: '',
                kqperiod: '',
                sysyear: '2020',
                sysmonth: '01',
            },
            rules: {
                comid: [{ required: true, min: 18, max: 18, message: "请输入国家提供的18位企业信用号码！" }],

                comname: [{ required: true, min: 2, max: 18, message: "请输入企业名称！" }],

                salperiod: [{
                    required: true, min: 1, max: 18, message: "薪资周期需要数字！",
                    parttern: /^((0?[0-9]{1})|([1,2]{1}[0-9]{1}))$/,
                }],
                kqperiod: [{
                    required: true, min: 1, max: 18, message: "考勤周期需要数字！",
                    parttern: /^((0?[0-9]{1})|([1,2]{1}[0-9]{1}))$/,
                }],
                sysyear: [{
                    required: true, min: 4, max: 4, message: "系统年度需要4位大于2020的数字！",
                    parttern: /^([2-3]{1}[0-9]{1}[0-9]{1}[0-9]{1})$/,
                }],
                sysmonth: [{
                    required: true, min: 1, max: 2, message: "系统月份需要数字！",
                    parttern: /^((0?[0-9]{1})|([1,2]{1}[0-9]{1}))$/,
                }],
            }
        }
    },
    mounted() {
        this.listMain();
    },

    methods: {

        saveform() {

            console.log('ddd', this.$refs['form'])
            this.$refs.form.validate((valid) => {
                console.log(valid)
                if (valid) {
                    let updatestr = '/cominfo';
                    let requestType = 'post'

                    console.log(this.form.id, requestType, updatestr)
                    if (this.form.id) {
                        updatestr = '/cominfo/' + this.form.id;
                        requestType = 'put'
                    }

                    console.log(this.data, requestType, updatestr)

                    AX(requestType, updatestr, this.form).then(res => {
                        this.data = res.data;
                        this.listMain();
                    }).catch(e => {

                        console.log(e.message)
                        return;

                    })
                }
            })
        },
        listMain() {
            AX('get', '/cominfo').then(res => {
                if (res.data.length > 0) {
                    this.data = res.data;
                    this.form = res.data[0];
                }
            })
                .catch(e => console.log(e.message))
        },

    }
}


</script>
<style scoped>
.cominfo .el-form-item {
    width: 100%;
}
</style>

