<template>
    <!-- 工作表单 -->
    <div class="dialogform">
        <el-form :rules="rules" :model="form" ref="form">
            <el-row gutter="24">
                <el-col :span="6">
                    <div>
                        <el-form-item label="证书名称" :label-width="formLabelWidth" prop="cert">
                            <el-input
                                size="medium"
                                v-model="form.cert"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item
                            label="颁发机构"
                            :label-width="formLabelWidth"
                            prop="organization"
                        >
                            <el-input
                                size="medium"
                                v-model="form.organization"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>

                <el-col :span="6">
                    <div>
                        <el-form-item label="有效日期从" :label-width="formLabelWidth" prop="fromdate">
                            <el-date-picker
                                v-model="form.fromdate"
                                type="date"
                                placeholder="选择日期"
                                format="YYYY-MM-DD"
                            ></el-date-picker>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="有效日期到" :label-width="formLabelWidth" prop="todate">
                            <el-date-picker
                                v-model="form.todate"
                                type="date"
                                placeholder="选择日期"
                                format="YYYY-MM-DD"
                            ></el-date-picker>
                        </el-form-item>
                    </div>
                </el-col>
                <el-col :span="6">
                    <div>
                        <el-form-item label="奖励金额" :label-width="formLabelWidth" prop="bounty">
                            <el-input
                                size="medium"
                                v-model="form.bounty"
                                autocomplete="off"
                                prefix-icon="el-icon-edit"
                            ></el-input>
                        </el-form-item>
                    </div>
                </el-col>
            </el-row>

            <el-row :gutter="24">
                <el-col :span="24">
                    <el-form-item label="备注" :label-width="formLabelWidth">
                        <el-input size="medium" v-model="form.remark" autocomplete="off"></el-input>
                    </el-form-item>
                    <el-divider content-position="left">
                        <i class="el-icon-edit-outline">工作经历</i>
                    </el-divider>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col :span="24">
                    <el-table
                        :data="formData"
                        style="width:100%"
                        v-loading="loading"
                        element-loading-text="拼命加载中"
                        element-loading-spinner="el-icon-loading"
                        element-loading-background="rgba(0, 0, 0, 0.8)"
                        stripe
                    >
                        <el-table-column prop="cert" label="证书" fixed="left" width="180"></el-table-column>
                        <el-table-column prop="organization" label="颁发机构" width="100"></el-table-column>

                        <el-table-column prop="fromdate" label="有效日期从" width="100"></el-table-column>
                        <el-table-column prop="todate" label="有效日期到" width="100"></el-table-column>

                        <el-table-column prop="bounty" label="奖励金额" width="150"></el-table-column>

                        <el-table-column prop="remark" label="备注" width="180"></el-table-column>
                        <el-table-column prop="id" fixed="right" label="操作" width="120">
                            <template #default="scope">
                                <span class="butgrp">
                                    <el-button
                                        size="mini"
                                        icon="el-icon-edit"
                                        @click="editform(scope.$index, scope.row)"
                                    ></el-button>

                                    <el-button
                                        size="mini"
                                        type="danger"
                                        icon="el-icon-delete"
                                        @click="delform(scope.$index, scope.row)"
                                    ></el-button>
                                </span>
                            </template>
                        </el-table-column>
                    </el-table>
                </el-col>
            </el-row>
            <el-row :gutter="24">
                <el-col
                    :span="24"
                    style="display:flex; justify-content: flex-end;padding-top:15px;"
                >
                    <el-button
                        type="success"
                        icon="el-icon-plus"
                        @click="init_form"
                        v-if="is_new == false"
                    ></el-button>

                    <el-button type="success" @click="saveform" v-if="is_new == true">新 增</el-button>
                    <el-button @click="closeform">取 消</el-button>
                    <el-button type="primary" @click="saveform" v-if="is_new == false">保 存</el-button>
                </el-col>
            </el-row>
        </el-form>
    </div>
</template>
<script>
import { AX, } from '../utils/api';
import { ref } from 'vue';


export default {

    props: {
        fsysid: {
            type: String,
            required: true
        }
    },

    data() {
        return {

            selfRouter: 'cert',


            formData: [],

            loading: false,

            is_new: true,

            dialogFormVisible: false,

            formLabelWidth: 200,

            form: {
                sysid: ref(''),
                cert: '',
                organization: '',
                bounty: '0',
                fromdate: '',
                todate: '',
                remark: '',
            },
            rules: {

                cert: [{ required: true, message: '请输入 证书名称', trigger: 'blur' }],

                bounty: [{ required: true, message: '请输入 奖励金额，没有写0', trigger: 'blur', pattern: /^(0|0(.)?\d+|[1-9]\d*(.)?\d*)$/ }],

                fromdate: [{ required: true, message: '请选择 有效日期从', trigger: 'blur' }],

                todate: [{ required: true, message: '请选择 有效日期到', trigger: 'blur' }],

            },


        }
    },
    mounted() {
        this.listMain();
    },
    watch: {
        fsysid() {
            this.listMain()

        }
    },
    methods: {

        init_form() {

            this.is_new = true;

            const keyitems = ['sysid', 'createdat', 'updatedat', 'deletedat'];

            for (let item in this.form) {

                if (keyitems.includes(item.toString().toLowerCase()) == false) {

                    this.form[item] = '';
                }
            }
            this.form.bounty = '0'

        },

        closeform() {

            this.$emit('close' + this.selfRouter + 'Form', false);

        },


        delform(idx, row) {


            this.$confirm('此操作将永久删除该记录, 是否继续?', '提示', {
                confirmButtonText: '确定',
                cancelButtonText: '取消',
                type: 'warning'
            }).then(() => {
                AX('DELETE', '/' + this.selfRouter + '/' + row.id).then((res) => {
                    if (res) {
                        this.listMain();
                    }
                })
            }).catch(() => {

                this.$message({
                    type: 'info',
                    message: '已取消删除'
                });
            });

        },

        editform(idx, row) {
            //  console.log(idx, row);
            this.is_new = false;
            this.form = Object.assign({}, row);
        },


        saveform() {

            this.$refs.form.validate((valid) => {

                if (valid) {


                    if (!this.is_new) {

                        AX('put', '/' + this.selfRouter + '/' + this.form.id, this.form).then((res) => {

                            if (res) {

                                this.dialogFormVisible = false;
                                this.listMain();
                                this.init_form();
                            }
                        })

                    }
                    else {

                        if (this.fsysid) {
                            this.form.sysid = this.fsysid;
                            AX('post', '/' + this.selfRouter, this.form).then((res) => {

                                if (res) {

                                    this.dialogFormVisible = false;
                                    this.listMain();
                                    this.init_form();
                                }
                            })

                        }
                    }

                }
            })
        },

        listMain() {

            AX('get', '/' + this.selfRouter + '/' + this.fsysid).then(res => {



                this.formData = res.data;

                this.loading = false;



            }
            )
        }
    }

}
</script>
<style scoped>
.el-dialog__body {
    text-align: left;
}
.input-with-select {
    width: 360px;
    margin-left: 10px;
}
.dialogform {
    display: flex;
    margin: 0 0;
}
.el-form-item {
    margin-bottom: 4px;
}
.el-form-item__content {
    display: flex;
}
td {
    padding: 4px 0;
}
.el-table td,
.el-table th {
    padding: 0;
}

.el-menu {
    padding: 0;
}
.label-width {
    width: 200px;
}
.el-select,
.el-date-picker {
    width: 100%;
}

.ispos {
    color: white;
    background-color: #409eff;
    padding: 2px 6px;
    cursor: pointer;
    font-size: 12px;
    border-radius: 5px;
}
.el-divider i {
    color: #409eff;
}
</style>


