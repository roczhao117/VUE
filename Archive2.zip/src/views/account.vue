<template>
  <div class="about">
    <el-container>
      <el-tabs type="border-card" style="width:99%;" v-model="activeTab">
        <el-tab-pane label="用户管理" name="user">
          <user></user>
        </el-tab-pane>
        <el-tab-pane label="账号策略" name="policy">
          <policy></policy>
        </el-tab-pane>
        <el-tab-pane label="角色管理" name="role">
          <role></role>
        </el-tab-pane>
      </el-tabs>
    </el-container>
  </div>
</template>


<script>
import user from '../components/user.vue'
import policy from '../components/policy.vue'
import role from '../components/role.vue'

export default {
  data() {
    return {
      activeTab: "policy",
    }
  },

  components: { user, policy, role, },

}


</script>,
    Role
