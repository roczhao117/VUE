<template>
  <div class="about">
    <h3>上海思百克软件科技有限公司</h3>
    <h1>support@specicsoft.com</h1>
    <h1>+86 21 5898 9819</h1>
  </div>
</template>

<script>
</script>
<style scoped>
body {
  margin: 0 0;
}
</style>