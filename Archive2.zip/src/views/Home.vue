<template>
  <div style="height:100%">
    <el-container>
      <el-header>
        <div id="header">
          <el-avatar src="https://cube.elemecdn.com/0/88/03b0d39583f48206768a7534e55bcpng.png"></el-avatar>
          <span style="margin:0px 2px;font-weight:bold;color:ghostwhite;">
            <i class="tbar" style="font-size:21px;">{{ $store.getters.userid }}</i>
          </span>
          <span style="align-self:flex-end;" @click="loginout">
            <i class="tbar">loginout</i>
          </span>
        </div>
      </el-header>
      <el-container>
        <el-aside width="200px;">
          <el-menu :default-openeds="['1', '3']" router style="border:0;">
            <div v-for="(item,index) in this.$router.options.routes" :key="index">
              <el-submenu index="1" v-if="!item.hidden">
                <template #title>
                  <i :class="item.icon"></i>
                  <span>{{ item.name }}</span>
                </template>
                <el-menu-item
                  :index="children.path"
                  v-for="(children,index) in item.children"
                  :key="index"
                >{{ children.name }}</el-menu-item>
              </el-submenu>
            </div>
          </el-menu>
        </el-aside>
        <el-container>
          <el-main>
            <router-view />
          </el-main>
        </el-container>
      </el-container>
    </el-container>
  </div>
</template>

<script>
import store from '../store'
export default {
  name: "Home",
  store,
  data() {
    return {
      circleUrl: "https://cube.elemecdn.com/3/7c/3ea6beec64369c2642b92c6726f1epng.png",
      squareUrl: "https://cube.elemecdn.com/9/c2/f0ee8a3c7c9638a54940382568c9dpng.png",
      sizeList: ["large", "medium", "small"]
    }
  },
  methods: {
    menuClick(index) {
      this.$router.push(index);
    },
    loginout() {
      window.localStorage.removeItem('token');
      this.$router.push('/');
    }
  }

};
</script>

<style>
html,
body {
  margin: 0 0;
  height: 100%;
}
.el-container {
  height: 100%;
  min-height: 200px;
  min-width: 1280px;
}

.el-header,
.el-footer {
  background-color: #303133;
  color: #333;
  text-align: center;
  line-height: 60px;
}

.el-aside {
  background-color: #ffffff;
  color: #333;
  text-align: center;
  line-height: 200px;
  height: 100%;
  border: 1px solid #e6e6e6;
}

.el-main {
  background-color: #ffffff;
  color: #333;
  text-align: center;
  /* line-height: 160px; */
  height: 100%;
}

body > .el-container {
  margin-bottom: 40px;
}

.el-container:nth-child(5) .el-aside,
.el-container:nth-child(6) .el-aside {
  line-height: 260px;
}

.el-container:nth-child(7) .el-aside {
  line-height: 320px;
}
#header {
  display: flex;
  align-items: center;
  justify-content: space-between;
}
.tbar {
  height: 40px;

  text-transform: capitalize;
}
#header span:nth-child(2) {
  flex: 1;
  text-align: left;
  padding: 0 10px;
  display: flex;
}
#header span:nth-child(3) {
  color: white;
  font-weight: bold;
  cursor: pointer;
  text-align: left;
  display: flex;
  margin: 10px 0px;
}

#header span:nth-child(3):hover {
  color: rgb(255, 127, 53);
}
</style>