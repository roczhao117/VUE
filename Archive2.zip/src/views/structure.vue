<template>
  <div class="about">
    <el-container>
      <el-tabs type="border-card" style="width:100%">
        <el-tab-pane label="组织信息">
          <cominfo></cominfo>
        </el-tab-pane>
        <el-tab-pane label="组织结构">
          <deptpos></deptpos>
        </el-tab-pane>
        <el-tab-pane label="成本结构">
          <cost></cost>
        </el-tab-pane>
        <el-tab-pane label="功能结构">
          <homemenu></homemenu>
        </el-tab-pane>
      </el-tabs>
    </el-container>
  </div>
</template>

<script>
import deptpos from '../components/deptpos.vue'
import cost from "../components/cost.vue"
import homemenu from '../components/menu.vue'
import cominfo from '../components/cominfo.vue'

export default {

  components: { deptpos, cost, homemenu, cominfo },


}


</script>