<template>
  <div class="about">
    <el-container>
      <el-tabs type="border-card" style="width:100%">
        <el-tab-pane label="系统参数">
          <dic></dic>
        </el-tab-pane>
        <el-tab-pane label="配置管理">配置管理</el-tab-pane>
        <el-tab-pane label="角色管理">角色管理</el-tab-pane>
        <el-tab-pane label="定时任务补偿">定时任务补偿</el-tab-pane>
      </el-tabs>
    </el-container>
  </div>
</template>


<script>
import dic from '../components/dic.vue'
//import { AX } from '../utils/api'
export default {
  components: { dic, },

}


</script>