<template>
  <div style="min-width:100px;">
    <el-container>
      <el-tabs type="border-card" style="width:100%">
        <el-tab-pane label="人事信息" name="HR">
          <hrinfo></hrinfo>
        </el-tab-pane>
        <el-tab-pane label="奖惩管理">配置管理</el-tab-pane>
        <el-tab-pane label="证件管理">角色管理</el-tab-pane>
        <el-tab-pane label="调动管理">定时任务补偿</el-tab-pane>
        <el-tab-pane label="合同管理">定时任务补偿</el-tab-pane>
        <el-tab-pane label="领用管理">定时任务补偿</el-tab-pane>
        <el-tab-pane label="面试信息">定时任务补偿</el-tab-pane>
        <el-tab-pane label="附件管理">定时任务补偿</el-tab-pane>
      </el-tabs>
    </el-container>
  </div>
</template>


<script>
import hrinfo from '../components/hrinfo.vue'
export default {
  components: { hrinfo, },


}


</script>